from Core_function.hand_planner import HandPlanner, PlannerConfig
from pprint import pprint

song = [
    ("C4", 0.40),
    ("A#3", 0.40),
    ("A3", 0.40),
    ("E4", 0.40),
    ("REST", 0.20),
    ("C4", 0.50),
]

cfg = PlannerConfig(
    note_min="E3",
    note_max="E5",
    start_center_note="C4",
    start_spread=0,
    enable_left_black_finger=True,
)

planner = HandPlanner(cfg)
planned_song = planner.plan_song(song)

pprint(planned_song)