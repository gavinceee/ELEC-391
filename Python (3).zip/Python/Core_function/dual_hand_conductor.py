# Core_function/dual_hand_conductor.py
from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any

from Core_function.note import note_to_angle


SPREAD_LEVEL_TO_ANGLE = {
    0: 0.0,
    1: 40.0,
    2: 80.0,
    3: 120.0,
    4: 160.0,
}


@dataclass
class ScheduledHandEvent:
    hand: str                    # "left" / "right"
    index: int                   # index in that hand's planned list
    start_time: float            # score time
    end_time: float              # score time
    duration: float

    notes: List[str]
    is_rest: bool
    planned_event: dict

    target_center_angle: Optional[float]
    target_spread_angle: Optional[float]
    target_spread_level: int

    # only for attack events
    attack_id: Optional[int] = None
    prepare_time: Optional[float] = None

    # runtime state
    idle_prepare_sent: bool = False
    prepare_sent: bool = False
    press_sent: bool = False
    release_sent: bool = False

    actual_press_time: Optional[float] = None
    actual_release_due: Optional[float] = None


@dataclass
class AttackGroup:
    attack_id: int
    attack_time: float
    members: Dict[str, ScheduledHandEvent] = field(default_factory=dict)

    ready_hands: set = field(default_factory=set)
    failed_hands: set = field(default_factory=set)

    press_sent: bool = False
    late_logged: bool = False


class DualHandConductor(threading.Thread):
    """
    Global conductor:
      planned_left / planned_right
          -> build per-hand timeline
          -> group simultaneous attacks
          -> time + ready gating
          -> emit commands to left/right worker queues

    This class does NOT talk to serial directly.
    It sends high-level commands to worker queues.

    ----------------------------------------------------------------
    Worker command queue protocol (input to your future hand workers)
    ----------------------------------------------------------------
    Command dict examples:

    1) Rest / idle reposition (no press)
    {
        "type": "idle_prepare",
        "hand": "left",
        "event_index": 3,
        "start_time": 2.40,
        "end_time": 2.90,
        "event": <planned_event_dict>,
    }

    2) Prepare for an attack
    {
        "type": "prepare",
        "hand": "right",
        "attack_id": 7,
        "event_index": 5,
        "attack_time": 3.50,
        "event": <planned_event_dict>,
    }

    3) Press now
    {
        "type": "press",
        "hand": "right",
        "attack_id": 7,
        "event_index": 5,
        "event": <planned_event_dict>,
    }

    4) Release now
    {
        "type": "release",
        "hand": "right",
        "attack_id": 7,
        "event_index": 5,
        "event": <planned_event_dict>,
    }

    5) Stop
    {
        "type": "stop",
        "hand": "left" / "right",
    }

    ----------------------------------------------------------------
    Worker status queue protocol (output from your future hand workers)
    ----------------------------------------------------------------
    Status dict examples:

    1) Ready for attack
    {
        "type": "ready",
        "hand": "left",
        "attack_id": 7,
    }

    2) Error
    {
        "type": "error",
        "hand": "right",
        "attack_id": 7,          # optional
        "message": "spread timeout",
    }

    Optional later:
    - "pressed"
    - "released"
    - "home_done"
    """

    def __init__(
        self,
        planned_left: Optional[List[dict]] = None,
        planned_right: Optional[List[dict]] = None,

        left_cmd_q: Optional[queue.Queue] = None,
        right_cmd_q: Optional[queue.Queue] = None,
        left_status_q: Optional[queue.Queue] = None,
        right_status_q: Optional[queue.Queue] = None,

        out_q: Optional[queue.Queue] = None,
        stop_evt: Optional[threading.Event] = None,
        pause_evt: Optional[threading.Event] = None,

        # grouping / sync
        sync_epsilon_s: float = 0.005,
        attack_grace_s: float = 0.10,
        scheduler_tick_s: float = 0.002,

        # late policy:
        #   "wait_all"   -> keep waiting for all required hands
        #   "skip_missing" -> after grace, press ready hands only
        late_policy: str = "wait_all",

        # prepare lead estimation
        prepare_base_s: float = 0.08,
        prepare_center_k_s_per_deg: float = 0.0035,
        prepare_spread_k_s_per_deg: float = 0.0020,
        prepare_min_s: float = 0.05,
        prepare_max_s: float = 0.60,
    ):
        super().__init__(daemon=True)

        self.planned_left = self._normalize_planned_song(planned_left or [])
        self.planned_right = self._normalize_planned_song(planned_right or [])

        self.left_cmd_q = left_cmd_q if left_cmd_q is not None else queue.Queue()
        self.right_cmd_q = right_cmd_q if right_cmd_q is not None else queue.Queue()
        self.left_status_q = left_status_q if left_status_q is not None else queue.Queue()
        self.right_status_q = right_status_q if right_status_q is not None else queue.Queue()

        self.out_q = out_q
        self.stop_evt = stop_evt if stop_evt is not None else threading.Event()
        self.pause_evt = pause_evt if pause_evt is not None else threading.Event()

        self.sync_epsilon_s = max(0.0, float(sync_epsilon_s))
        self.attack_grace_s = max(0.0, float(attack_grace_s))
        self.scheduler_tick_s = max(0.001, float(scheduler_tick_s))
        self.late_policy = str(late_policy).strip().lower()

        self.prepare_base_s = float(prepare_base_s)
        self.prepare_center_k_s_per_deg = float(prepare_center_k_s_per_deg)
        self.prepare_spread_k_s_per_deg = float(prepare_spread_k_s_per_deg)
        self.prepare_min_s = float(prepare_min_s)
        self.prepare_max_s = float(prepare_max_s)

        self._elapsed_paused_accum = 0.0
        self._pause_notified = False

        self.left_events: List[ScheduledHandEvent] = []
        self.right_events: List[ScheduledHandEvent] = []
        self.attack_groups: List[AttackGroup] = []

        self._timeline_shift_s = 0.0

        # runtime hand availability
        self._hand_busy_until = {
            "left": 0.0,
            "right": 0.0,
        }

    # ============================================================
    # Public helpers
    # ============================================================

    def get_worker_queues(self):
        return {
            "left_cmd_q": self.left_cmd_q,
            "right_cmd_q": self.right_cmd_q,
            "left_status_q": self.left_status_q,
            "right_status_q": self.right_status_q,
        }

    # ============================================================
    # Basic normalization
    # ============================================================

    def _normalize_note(self, x) -> str:
        s = str("" if x is None else x).strip().upper()
        return s

    def _normalize_notes(self, xs) -> List[str]:
        if xs is None:
            return []

        if isinstance(xs, str):
            s = self._normalize_note(xs)
            if s in ("", "REST"):
                return []
            return [n.strip().upper() for n in s.split("/") if n.strip()]

        out = []
        seen = set()
        for x in xs:
            n = self._normalize_note(x)
            if n in ("", "REST"):
                continue
            if n not in seen:
                seen.add(n)
                out.append(n)
        return out

    def _safe_duration(self, x) -> float:
        try:
            d = float(x)
        except Exception:
            d = 0.0
        return max(0.01, d)

    def _safe_int(self, x, default=0) -> int:
        try:
            return int(x)
        except Exception:
            return int(default)

    def _normalize_planned_song(self, seq: List[dict]) -> List[dict]:
        out = []
        for ev in seq:
            if not isinstance(ev, dict):
                continue

            notes = self._normalize_notes(ev.get("notes", []))
            duration = self._safe_duration(ev.get("duration", 0.1))
            center_note = self._normalize_note(ev.get("center_note", ""))
            spread = self._safe_int(ev.get("spread", 0), 0)

            try:
                center_angle_override = (
                    None if ev.get("center_angle_override") is None
                    else float(ev.get("center_angle_override"))
                )
            except Exception:
                center_angle_override = None

            try:
                spread_angle_override = (
                    None if ev.get("spread_angle_override") is None
                    else float(ev.get("spread_angle_override"))
                )
            except Exception:
                spread_angle_override = None

            out.append({
                "notes": notes,
                "duration": duration,
                "center_note": center_note,
                "spread": spread,
                "finger_ids": list(ev.get("finger_ids", [])),
                "note_finger_map": dict(ev.get("note_finger_map", {})),
                "action_type": str(ev.get("action_type", "hold_shape")),

                "center_mode": ev.get("center_mode"),
                "center_slot": ev.get("center_slot"),
                "spread_profile": ev.get("spread_profile"),
                "center_angle_override": center_angle_override,
                "spread_angle_override": spread_angle_override,
                "source_path": ev.get("source_path"),
            })
        return out

    # ============================================================
    # Logging / output
    # ============================================================

    def _emit(self, kind: str, payload: Any):
        if self.out_q is not None:
            self.out_q.put((kind, payload))

    def _log(self, msg: str):
        self._emit("status", f"[DHC] {msg}")

    # ============================================================
    # Timing helpers
    # ============================================================

    def _elapsed(self, t0: float) -> float:
        return max(0.0, time.perf_counter() - t0 - self._elapsed_paused_accum)

    def _handle_pause(self, t0: float) -> Optional[float]:
        if not self.pause_evt.is_set():
            self._pause_notified = False
            return self._elapsed_paused_accum

        pause_start = time.perf_counter()

        if not self._pause_notified:
            self._emit("dhc_paused", {"elapsed": self._elapsed(t0)})
            self._pause_notified = True

        while self.pause_evt.is_set() and not self.stop_evt.is_set():
            self._emit("dhc_time", self._elapsed(t0))
            time.sleep(0.02)

        if self.stop_evt.is_set():
            return None

        paused_for = time.perf_counter() - pause_start
        self._elapsed_paused_accum += paused_for
        self._emit("dhc_resumed", {
            "elapsed": self._elapsed(t0),
            "paused_for": paused_for,
        })
        self._pause_notified = False
        return self._elapsed_paused_accum

    def _shifted_start_time(self, ev: ScheduledHandEvent) -> float:
        return float(ev.start_time) + float(self._timeline_shift_s)

    def _shifted_prepare_time(self, ev: ScheduledHandEvent) -> Optional[float]:
        if ev.prepare_time is None:
            return None
        return float(ev.prepare_time) + float(self._timeline_shift_s)

    def _shifted_attack_time(self, g: AttackGroup) -> float:
        return float(g.attack_time) + float(self._timeline_shift_s)
    # ============================================================
    # Pose / prepare estimation
    # ============================================================

    def _event_center_angle(self, ev: dict, hand: str) -> Optional[float]:
        try:
            if ev.get("center_angle_override", None) is not None:
                return float(ev["center_angle_override"])
        except Exception:
            pass

        center_note = self._normalize_note(ev.get("center_note", ""))
        if not center_note:
            return None

        try:
            return float(note_to_angle(center_note, hand))
        except Exception:
            return None

    def _event_spread_angle(self, ev: dict) -> Optional[float]:
        try:
            if ev.get("spread_angle_override", None) is not None:
                return float(ev["spread_angle_override"])
        except Exception:
            pass

        spread_level = self._safe_int(ev.get("spread", 0), 0)
        return SPREAD_LEVEL_TO_ANGLE.get(spread_level, 0.0)

    def _estimate_prepare_lead(
        self,
        prev_center_angle: Optional[float],
        prev_spread_angle: Optional[float],
        ev: dict,
        hand: str,
    ) -> float:
        cur_center = self._event_center_angle(ev, hand)
        cur_spread = self._event_spread_angle(ev)

        delta_center = 0.0
        if prev_center_angle is not None and cur_center is not None:
            delta_center = abs(cur_center - prev_center_angle)

        delta_spread = 0.0
        if prev_spread_angle is not None and cur_spread is not None:
            delta_spread = abs(cur_spread - prev_spread_angle)

        lead = (
            self.prepare_base_s
            + self.prepare_center_k_s_per_deg * delta_center
            + self.prepare_spread_k_s_per_deg * delta_spread
        )
        lead = max(self.prepare_min_s, lead)
        lead = min(self.prepare_max_s, lead)
        return lead

    # ============================================================
    # Schedule building
    # ============================================================

    def _build_hand_schedule(self, planned_song: List[dict], hand: str) -> List[ScheduledHandEvent]:
        items: List[ScheduledHandEvent] = []

        t = 0.0
        prev_center_angle = None
        prev_spread_angle = None
        prev_end_time = 0.0

        for idx, ev in enumerate(planned_song):
            duration = self._safe_duration(ev.get("duration", 0.1))
            start_time = t
            end_time = t + duration

            notes = self._normalize_notes(ev.get("notes", []))
            is_rest = (len(notes) == 0)

            target_center_angle = self._event_center_angle(ev, hand)
            target_spread_angle = self._event_spread_angle(ev)
            target_spread_level = self._safe_int(ev.get("spread", 0), 0)

            if is_rest:
                item = ScheduledHandEvent(
                    hand=hand,
                    index=idx,
                    start_time=start_time,
                    end_time=end_time,
                    duration=duration,
                    notes=notes,
                    is_rest=True,
                    planned_event=ev,
                    target_center_angle=target_center_angle,
                    target_spread_angle=target_spread_angle,
                    target_spread_level=target_spread_level,
                )
            else:
                lead = self._estimate_prepare_lead(
                prev_center_angle=prev_center_angle,
                prev_spread_angle=prev_spread_angle,
                ev=ev,
                hand=hand,
                )

                # first version: no same-hand preload while previous note is still sounding
                prepare_time = max(0.0, start_time - lead, prev_end_time)

                item = ScheduledHandEvent(
                    hand=hand,
                    index=idx,
                    start_time=start_time,
                    end_time=end_time,
                    duration=duration,
                    notes=notes,
                    is_rest=False,
                    planned_event=ev,
                    target_center_angle=target_center_angle,
                    target_spread_angle=target_spread_angle,
                    target_spread_level=target_spread_level,
                    prepare_time=prepare_time,
                )

            items.append(item)

            # pose state always updates to this event target
            prev_center_angle = target_center_angle
            prev_spread_angle = target_spread_angle
            prev_end_time = end_time
            t = end_time

        return items

    def _build_attack_groups(
        self,
        left_events: List[ScheduledHandEvent],
        right_events: List[ScheduledHandEvent],
    ) -> List[AttackGroup]:
        attack_items = [x for x in (left_events + right_events) if not x.is_rest]
        attack_items.sort(key=lambda e: (e.start_time, 0 if e.hand == "left" else 1))

        groups: List[AttackGroup] = []
        next_attack_id = 1

        for ev in attack_items:
            if not groups:
                g = AttackGroup(attack_id=next_attack_id, attack_time=ev.start_time)
                g.members[ev.hand] = ev
                groups.append(g)
                next_attack_id += 1
                continue

            last = groups[-1]
            if abs(ev.start_time - last.attack_time) <= self.sync_epsilon_s:
                last.members[ev.hand] = ev
            else:
                g = AttackGroup(attack_id=next_attack_id, attack_time=ev.start_time)
                g.members[ev.hand] = ev
                groups.append(g)
                next_attack_id += 1

        # write back attack_id
        for g in groups:
            for hand, ev in g.members.items():
                ev.attack_id = g.attack_id

        return groups

    # ============================================================
    # Status intake
    # ============================================================

    def _drain_status_queue(self, hand: str, qobj: queue.Queue, groups_by_id: Dict[int, AttackGroup]):
        while True:
            try:
                msg = qobj.get_nowait()
            except queue.Empty:
                break

            if not isinstance(msg, dict):
                continue

            typ = str(msg.get("type", "")).strip().lower()
            attack_id = msg.get("attack_id", None)

            if typ == "ready":
                if attack_id is None:
                    continue
                g = groups_by_id.get(int(attack_id))
                if g is None:
                    continue
                g.ready_hands.add(hand)
                self._emit("dhc_ready", {
                    "hand": hand,
                    "attack_id": int(attack_id),
                    "ready_hands": sorted(list(g.ready_hands)),
                })

            elif typ == "error":
                text = str(msg.get("message", "worker error"))
                if attack_id is not None:
                    g = groups_by_id.get(int(attack_id))
                    if g is not None:
                        g.failed_hands.add(hand)
                self._emit("error", f"[DHC] {hand} worker error: {text}")

    # ============================================================
    # Command send helpers
    # ============================================================

    def _cmd_q_for_hand(self, hand: str) -> queue.Queue:
        return self.left_cmd_q if hand == "left" else self.right_cmd_q

    def _send_idle_prepare(self, ev: ScheduledHandEvent):
        qobj = self._cmd_q_for_hand(ev.hand)
        qobj.put({
            "type": "idle_prepare",
            "hand": ev.hand,
            "event_index": ev.index,
            "start_time": ev.start_time,
            "end_time": ev.end_time,
            "event": ev.planned_event,
        })
        ev.idle_prepare_sent = True
        self._emit("dhc_idle_prepare", {
            "hand": ev.hand,
            "event_index": ev.index,
            "start_time": ev.start_time,
            "end_time": ev.end_time,
        })

    def _send_prepare(self, ev: ScheduledHandEvent):
        qobj = self._cmd_q_for_hand(ev.hand)
        qobj.put({
            "type": "prepare",
            "hand": ev.hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "attack_time": ev.start_time,
            "event": ev.planned_event,
        })
        ev.prepare_sent = True
        self._emit("dhc_prepare", {
            "hand": ev.hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "prepare_time": ev.prepare_time,
            "attack_time": ev.start_time,
        })

    def _send_press(self, hand: str, ev: ScheduledHandEvent):
        qobj = self._cmd_q_for_hand(hand)
        qobj.put({
            "type": "press",
            "hand": hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "event": ev.planned_event,
        })
        self._emit("dhc_press", {
            "hand": hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "notes": list(ev.notes),
        })

    def _send_release(self, hand: str, ev: ScheduledHandEvent):
        qobj = self._cmd_q_for_hand(hand)
        qobj.put({
            "type": "release",
            "hand": hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "event": ev.planned_event,
        })
        ev.release_sent = True
        self._emit("dhc_release", {
            "hand": hand,
            "attack_id": ev.attack_id,
            "event_index": ev.index,
            "notes": list(ev.notes),
        })

    def _broadcast_stop(self):
        self.left_cmd_q.put({"type": "stop", "hand": "left"})
        self.right_cmd_q.put({"type": "stop", "hand": "right"})

    # ============================================================
    # Main loop
    # ============================================================

    def run(self):
        self.left_events = self._build_hand_schedule(self.planned_left, "left")
        self.right_events = self._build_hand_schedule(self.planned_right, "right")
        self.attack_groups = self._build_attack_groups(self.left_events, self.right_events)

        groups_by_id = {g.attack_id: g for g in self.attack_groups}
        all_events = self.left_events + self.right_events

        self._emit("dhc_started", {
            "left_total": len(self.left_events),
            "right_total": len(self.right_events),
            "attack_groups": len(self.attack_groups),
        })

        t0 = time.perf_counter()

        while not self.stop_evt.is_set():
            paused_accum = self._handle_pause(t0)
            if paused_accum is None:
                break

            now = self._elapsed(t0)
            self._emit("dhc_time", now)

            # 1) read worker status
            self._drain_status_queue("left", self.left_status_q, groups_by_id)
            self._drain_status_queue("right", self.right_status_q, groups_by_id)

            # 2) independent release FIRST
            for ev in all_events:
                if ev.is_rest:
                    continue
                if not ev.press_sent:
                    continue
                if ev.release_sent:
                    continue
                if ev.actual_release_due is None:
                    continue
                if now < ev.actual_release_due:
                    continue

                self._send_release(ev.hand, ev)

            # 3) dispatch idle rest prepare
            for ev in all_events:
                if not ev.is_rest:
                    continue
                if ev.idle_prepare_sent:
                    continue
                effective_start_time = self._shifted_start_time(ev)
                if now < effective_start_time:
                    continue
                if now < self._hand_busy_until[ev.hand]:
                    continue
                self._send_idle_prepare(ev)

            # 4) dispatch attack prepare
            for g in self.attack_groups:
                for hand, ev in g.members.items():
                    if ev.prepare_sent:
                        continue
                    effective_prepare_time = self._shifted_prepare_time(ev)
                    if effective_prepare_time is None:
                        continue
                    if now < effective_prepare_time:
                        continue
                    if now <= self._hand_busy_until[hand]:
                        continue
                    self._send_prepare(ev)


            # 5) independent release
            for ev in all_events:
                if ev.is_rest:
                    continue
                if not ev.press_sent:
                    continue
                if ev.release_sent:
                    continue
                if ev.actual_release_due is None:
                    continue
                if now < ev.actual_release_due:
                    continue

                self._send_release(ev.hand, ev)

            # 6) finish condition
            all_done = True
            for ev in all_events:
                if ev.is_rest:
                    continue
                if not ev.release_sent:
                    all_done = False
                    break

            if all_done:
                final_elapsed = now
                self._emit("dhc_done", {"elapsed": final_elapsed})
                return

            time.sleep(self.scheduler_tick_s)

        # stop / cancelled
        self._broadcast_stop()
        self._emit("dhc_stop", {"elapsed": self._elapsed(t0)})