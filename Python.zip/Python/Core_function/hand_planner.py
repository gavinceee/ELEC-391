from __future__ import annotations

from dataclasses import dataclass
from math import inf
from typing import Dict, List, Optional, Tuple

# ============================================================
# 1) Basic note utilities
# ============================================================

NOTE_NAMES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#',
                    'G', 'G#', 'A', 'A#', 'B']

WHITE_PITCHES = {'C', 'D', 'E', 'F', 'G', 'A', 'B'}

FLAT_TO_SHARP = {
    'DB': 'C#',
    'EB': 'D#',
    'GB': 'F#',
    'AB': 'G#',
    'BB': 'A#',
}


def normalize_note(note: str) -> str:
    s = str(note).strip().upper()
    if s == "REST":
        return "REST"

    if len(s) < 2:
        raise ValueError(f"Bad note: {note!r}")

    if len(s) >= 3 and s[1] == 'B':
        pitch = s[:2]
        octave = s[2:]
        pitch = FLAT_TO_SHARP.get(pitch, pitch)
        return f"{pitch}{octave}"

    return s


def note_to_midi(note: str) -> int:
    n = normalize_note(note)

    if n == "REST":
        raise ValueError("REST has no MIDI number.")

    if len(n) >= 3 and n[1] == '#':
        pitch = n[:2]
        octave = int(n[2:])
    else:
        pitch = n[:1]
        octave = int(n[1:])

    if pitch not in NOTE_NAMES_SHARP:
        raise ValueError(f"Unsupported pitch: {note!r}")

    return NOTE_NAMES_SHARP.index(pitch) + (octave + 1) * 12


def midi_to_note(midi_num: int) -> str:
    pitch = NOTE_NAMES_SHARP[midi_num % 12]
    octave = (midi_num // 12) - 1
    return f"{pitch}{octave}"


def get_pitch_name(note: str) -> str:
    n = normalize_note(note)
    if n == "REST":
        return "REST"

    if len(n) >= 3 and n[1] == '#':
        return n[:2]
    return n[:1]


def is_white_note(note: str) -> bool:
    return get_pitch_name(note) in WHITE_PITCHES


def is_black_note(note: str) -> bool:
    n = normalize_note(note)
    if n == "REST":
        return False
    return not is_white_note(n)


def build_white_key_range(note_min: str, note_max: str) -> List[str]:
    lo = note_to_midi(note_min)
    hi = note_to_midi(note_max)

    if lo > hi:
        raise ValueError("note_min must be <= note_max.")

    out = []
    for m in range(lo, hi + 1):
        n = midi_to_note(m)
        if is_white_note(n):
            out.append(n)
    return out


def associated_black_for_white(white_note: str) -> Optional[str]:
    """
    Return the black-key slot associated with a white key.

    Rule:
    - Prefer the sharp of this white key (white + 1 semitone) if that is black.
    - If no sharp exists (e.g. E, B), fall back to the flat below (white - 1 semitone)
      if that is black.

    Examples:
        A  -> A#
        G  -> G#
        F  -> F#
        E  -> D#
        B  -> A#
    """
    w = normalize_note(white_note)
    if not is_white_note(w):
        return None

    m = note_to_midi(w)

    up = midi_to_note(m + 1)
    if is_black_note(up):
        return up

    down = midi_to_note(m - 1)
    if is_black_note(down):
        return down

    return None


# ============================================================
# 2) Planner dataclasses
# ============================================================

@dataclass(frozen=True)
class Pose:
    """
    center_idx: current middle-finger center on WHITE-key index
    spread:
        0 -> outer white fingers at ±2 white keys
        1 -> outer white fingers at ±3 white keys
        2 -> outer white fingers at ±4 white keys
    """
    center_idx: int
    spread: int


@dataclass(frozen=True)
class State:
    pose: Pose
    last_finger_id: Optional[str]   # "Lw", "Lb", "M", "Rb", "Rw", or None


@dataclass(frozen=True)
class Candidate:
    pose: Pose
    finger_id: Optional[str]        # None only for REST reposition


@dataclass
class PlannerConfig:
    # Keyboard range
    note_min: str = "E3"
    note_max: str = "E5"

    # spread 0/1/2 => outer white offsets ±2/±3/±4
    spread_distances: Tuple[int, ...] = (2, 3, 4)

    # Start pose
    start_center_note: Optional[str] = None
    start_spread: int = 0

    # Cost weights
    cost_hand_move_per_key: float = 10.0
    cost_spread_change_per_level: float = 2.0
    cost_finger_change: float = 0.6

    # REST can be used for reposition
    allow_rest_reposition: bool = True
    rest_move_discount: float = 0.50

    # Unsupported note handling
    unsupported_note_as_rest: bool = False

    # Enable black-key slots on both sides
    enable_left_black_finger: bool = True
    enable_right_black_finger: bool = True

    first_note_action_type: str = "move_hand"


# ============================================================
# 3) HandPlanner
# ============================================================

class HandPlanner:
    """
    Enabled model:
        Lw, Lb, M, Rb, Rw

    For each pose:
        M  -> center white
        Lw -> center - d  (white track)
        Rw -> center + d  (white track)

        Lb -> black slot associated with Lw
        Rb -> black slot associated with Rw

    This matches the mechanical idea that when motor2 changes spread:
        - white-key slots move outward together on the white track
        - black-key slots move outward together on the black track
    """

    VALID_FINGERS_NOW = ("Lw", "Lb", "M", "Rb", "Rw")

    def __init__(self, cfg: PlannerConfig):
        self.cfg = cfg

        self.white_keys: List[str] = build_white_key_range(cfg.note_min, cfg.note_max)
        if not self.white_keys:
            raise ValueError("White-key range is empty.")

        self.white_note_to_idx: Dict[str, int] = {
            normalize_note(n): i for i, n in enumerate(self.white_keys)
        }

        self.valid_poses: List[Pose] = self._build_valid_poses()

    # --------------------------------------------------------
    # Pose validity
    # --------------------------------------------------------
    def _pose_valid(self, center_idx: int, spread: int) -> bool:
        if spread < 0 or spread >= len(self.cfg.spread_distances):
            return False

        if center_idx < 0 or center_idx >= len(self.white_keys):
            return False

        d = self.cfg.spread_distances[spread]
        left_idx = center_idx - d
        right_idx = center_idx + d

        return (
            0 <= left_idx < len(self.white_keys) and
            0 <= right_idx < len(self.white_keys)
        )

    def _build_valid_poses(self) -> List[Pose]:
        out = []
        for center_idx in range(len(self.white_keys)):
            for spread in range(len(self.cfg.spread_distances)):
                if self._pose_valid(center_idx, spread):
                    out.append(Pose(center_idx, spread))
        return out

    # --------------------------------------------------------
    # Per-pose reachable notes
    # --------------------------------------------------------
    def _pose_note_map(self, pose: Pose) -> List[Tuple[str, str]]:
        """
        Return reachable (note, finger_id) pairs for one pose.
        """
        d = self.cfg.spread_distances[pose.spread]
        center_idx = pose.center_idx
        left_idx = center_idx - d
        right_idx = center_idx + d

        out: List[Tuple[str, str]] = []

        left_white = self.white_keys[left_idx]
        center_white = self.white_keys[center_idx]
        right_white = self.white_keys[right_idx]

        # left white
        out.append((left_white, "Lw"))

        # left black follows the left white slot
        if self.cfg.enable_left_black_finger:
            lb_note = associated_black_for_white(left_white)
            if lb_note is not None:
                out.append((lb_note, "Lb"))

        # middle
        out.append((center_white, "M"))

        # right black follows the right white slot
        if self.cfg.enable_right_black_finger:
            rb_note = associated_black_for_white(right_white)
            if rb_note is not None:
                out.append((rb_note, "Rb"))

        # right white
        out.append((right_white, "Rw"))

        return out

    # --------------------------------------------------------
    # Note support
    # --------------------------------------------------------
    def _note_supported_now(self, note: str) -> bool:
        n = normalize_note(note)

        if n == "REST":
            return True

        for pose in self.valid_poses:
            for pose_note, _finger_id in self._pose_note_map(pose):
                if normalize_note(pose_note) == n:
                    return True

        return False

    # --------------------------------------------------------
    # Candidate generation
    # --------------------------------------------------------
    def _note_candidates(self, note: str) -> List[Candidate]:
        n = normalize_note(note)
        if n == "REST":
            raise ValueError("REST should not go into _note_candidates().")

        out: List[Candidate] = []

        for pose in self.valid_poses:
            for pose_note, finger_id in self._pose_note_map(pose):
                if normalize_note(pose_note) == n:
                    out.append(Candidate(
                        pose=pose,
                        finger_id=finger_id,
                    ))

        uniq: Dict[Tuple[int, int, str], Candidate] = {}
        for c in out:
            uniq[(c.pose.center_idx, c.pose.spread, c.finger_id or "REST")] = c

        return list(uniq.values())

    def _rest_candidates(self) -> List[Candidate]:
        if not self.cfg.allow_rest_reposition:
            return []
        return [Candidate(pose=p, finger_id=None) for p in self.valid_poses]

    # --------------------------------------------------------
    # Costs
    # --------------------------------------------------------
    def _transition_cost(self, prev_state: State, cand: Candidate, is_rest: bool) -> float:
        hand_move = abs(cand.pose.center_idx - prev_state.pose.center_idx)
        spread_change = abs(cand.pose.spread - prev_state.pose.spread)

        finger_change = 0.0
        if cand.finger_id is not None and prev_state.last_finger_id is not None:
            if cand.finger_id != prev_state.last_finger_id:
                finger_change = 1.0

        move_scale = self.cfg.rest_move_discount if is_rest else 1.0

        total = 0.0
        total += hand_move * self.cfg.cost_hand_move_per_key * move_scale
        total += spread_change * self.cfg.cost_spread_change_per_level * move_scale
        total += finger_change * self.cfg.cost_finger_change
        return total

    # --------------------------------------------------------
    # Action label
    # --------------------------------------------------------
    @staticmethod
    def _action_type(prev_state: State, cand: Candidate) -> str:
        hand_changed = (cand.pose.center_idx != prev_state.pose.center_idx)
        spread_changed = (cand.pose.spread != prev_state.pose.spread)
        finger_changed = (cand.finger_id != prev_state.last_finger_id)

        if cand.finger_id is None:
            if hand_changed or spread_changed:
                return "rest_reposition"
            return "rest_hold"

        if hand_changed and spread_changed:
            return "move_hand_and_finger"
        if hand_changed:
            return "move_hand"
        if spread_changed or finger_changed:
            return "finger_only"
        return "hold_shape"

    # --------------------------------------------------------
    # Start state
    # --------------------------------------------------------
    def _make_start_state(self, song: List[Tuple[str, float]]) -> State:
        if self.cfg.start_center_note is not None:
            n = normalize_note(self.cfg.start_center_note)
            if n not in self.white_note_to_idx:
                raise ValueError(f"start_center_note {n!r} is outside white-key range.")
            wanted_center_idx = self.white_note_to_idx[n]
        else:
            wanted_center_idx = None
            for note, _ in song:
                nn = normalize_note(note)
                if nn != "REST" and nn in self.white_note_to_idx:
                    wanted_center_idx = self.white_note_to_idx[nn]
                    break

            if wanted_center_idx is None:
                wanted_center_idx = len(self.white_keys) // 2

        wanted_spread = max(0, min(self.cfg.start_spread, len(self.cfg.spread_distances) - 1))

        if self._pose_valid(wanted_center_idx, wanted_spread):
            return State(Pose(wanted_center_idx, wanted_spread), None)

        best_pose = None
        best_dist = inf
        for p in self.valid_poses:
            dist = abs(p.center_idx - wanted_center_idx) + abs(p.spread - wanted_spread)
            if dist < best_dist:
                best_dist = dist
                best_pose = p

        if best_pose is None:
            raise RuntimeError("No valid starting pose found.")

        return State(best_pose, None)

    # --------------------------------------------------------
    # Main API
    # --------------------------------------------------------
    def plan_song(self, song: List[Tuple[str, float]]) -> List[dict]:
        """
        Input:
            song = [(note_name, duration_sec), ...]

        Output:
            planned_song = [
                {
                    "note": str,
                    "duration": float,
                    "center_note": str,
                    "spread": int,
                    "finger_id": str,     # "Lw", "Lb", "M", "Rb", "Rw", or "REST"
                    "action_type": str,
                },
                ...
            ]
        """
        if not song:
            return []

        # 1) Clean input
        clean_song: List[Tuple[str, float]] = []
        for note, dur in song:
            nn = normalize_note(note)

            try:
                dd = max(0.01, float(dur))
            except Exception:
                dd = 0.01

            if nn != "REST" and not self._note_supported_now(nn):
                if self.cfg.unsupported_note_as_rest:
                    nn = "REST"
                else:
                    raise ValueError(f"Unsupported note in current mode: {note!r}")

            clean_song.append((nn, dd))

        # 2) Start state
        start_state = self._make_start_state(clean_song)

        dp: Dict[State, float] = {start_state: 0.0}
        history: List[Dict[State, Tuple[Optional[State], dict]]] = []

        # 3) Dynamic programming
        for idx, (note, duration) in enumerate(clean_song):
            is_rest = (note == "REST")

            if is_rest:
                cands = self._rest_candidates()
                if not cands:
                    cands = [Candidate(pose=st.pose, finger_id=None) for st in dp.keys()]
            else:
                cands = self._note_candidates(note)

            if not cands:
                raise RuntimeError(f"No valid candidates at idx={idx}, note={note!r}")

            next_dp: Dict[State, float] = {}
            step_back: Dict[State, Tuple[Optional[State], dict]] = {}

            for prev_state, prev_cost in dp.items():
                for cand in cands:
                    new_state = State(
                        pose=cand.pose,
                        last_finger_id=cand.finger_id,
                    )

                    step_cost = self._transition_cost(prev_state, cand, is_rest=is_rest)
                    total_cost = prev_cost + step_cost

                    if new_state not in next_dp or total_cost < next_dp[new_state]:

                        if idx == 0:
                            action_type = self.cfg.first_note_action_type
                        else:
                            action_type = self._action_type(prev_state, cand)
                            
                        runtime_event = {
                            "note": note,
                            "duration": duration,
                            "center_note": self.white_keys[cand.pose.center_idx],
                            "spread": cand.pose.spread,
                            "finger_id": cand.finger_id if cand.finger_id is not None else "REST",
                            "action_type": action_type,
                        }

                        next_dp[new_state] = total_cost
                        step_back[new_state] = (prev_state, runtime_event)

            dp = next_dp
            history.append(step_back)

        # 4) Choose best final state
        final_state = min(dp.keys(), key=lambda s: dp[s])

        # 5) Backtrack
        planned_rev: List[dict] = []
        cur = final_state

        for i in range(len(history) - 1, -1, -1):
            prev_state, event = history[i][cur]
            planned_rev.append(event)
            cur = prev_state

        return list(reversed(planned_rev))

    @staticmethod
    def pretty_print_plan(plan: List[dict]) -> None:
        for i, ev in enumerate(plan):
            print(
                f"[{i:02d}] "
                f"note={ev['note']:<4} dur={ev['duration']:.3f}  "
                f"center={ev['center_note']:<3} spread={ev['spread']}  "
                f"finger_id={ev['finger_id']:<4} action={ev['action_type']}"
            )


if __name__ == "__main__":
    song = [
        ("C4", 0.40),
        ("A#3", 0.40),
        ("A3", 0.40),
        ("D#4", 0.40),
        ("E4", 0.40),
        ("F#4", 0.40),
        ("F4", 0.40),
        ("G#4", 0.40),
        ("G4", 0.40),
    ]

    cfg = PlannerConfig(
        note_min="E3",
        note_max="E5",
        start_center_note="C4",
        start_spread=0,
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )

    planner = HandPlanner(cfg)
    planned_song = planner.plan_song(song)
    planner.pretty_print_plan(planned_song)