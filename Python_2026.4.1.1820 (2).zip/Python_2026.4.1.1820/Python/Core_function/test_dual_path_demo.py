from __future__ import annotations

import argparse
import importlib
import importlib.util
import os
import queue
import re
import sys
import threading
import time
import types
from pathlib import Path
from typing import List, Tuple, Optional, Any


# ============================================================
# Module bootstrap
# ============================================================

def _load_module_from_file(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module {module_name} from {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _ensure_pkg(pkg_name: str, path_hint: Path | None = None):
    if pkg_name not in sys.modules:
        pkg = types.ModuleType(pkg_name)
        pkg.__path__ = [] if path_hint is None else [str(path_hint)]
        sys.modules[pkg_name] = pkg
    return sys.modules[pkg_name]


def _find_module_root(script_dir: Path) -> Path:
    """
    Support both:
    1) script beside all .py files
    2) script in Core_function/, but files are still beside it
    3) script in project folder, package layout works directly
    """
    candidates = [script_dir, script_dir.parent]
    for root in candidates:
        if (root / "hand_planner.py").exists() and (root / "hand_planner_dual_path.py").exists():
            return root
    return script_dir


def bootstrap_modules(script_dir: Path):
    # First try normal package imports.
    try:
        note_mod = importlib.import_module("Core_function.note")
        hand_planner_mod = importlib.import_module("Core_function.hand_planner")
        dual_mod = importlib.import_module("Core_function.hand_planner_dual_path")
        seq_mod = importlib.import_module("Core_function.sequencer")
        try:
            midi_mod = importlib.import_module("Song.midi_loader")
        except Exception:
            midi_mod = None
        return {
            "note": note_mod,
            "hand_planner": hand_planner_mod,
            "hand_planner_dual_path": dual_mod,
            "sequencer": seq_mod,
            "midi_loader": midi_mod,
        }
    except Exception:
        pass

    root = _find_module_root(script_dir)
    _ensure_pkg("Core_function", root)
    _ensure_pkg("Song", root)

    note_mod = _load_module_from_file("Core_function.note", root / "note.py")
    setattr(sys.modules["Core_function"], "note", note_mod)

    hand_planner_mod = _load_module_from_file("Core_function.hand_planner", root / "hand_planner.py")
    setattr(sys.modules["Core_function"], "hand_planner", hand_planner_mod)

    # midi_loader must be loaded before dual_path, otherwise dual_path caches None.
    midi_mod = None
    midi_candidates = [
        root / "midi_loader.py",            # flat layout
        root / "Song" / "midi_loader.py",   # package sibling under current root
        root.parent / "Song" / "midi_loader.py",  # script inside Core_function/
    ]
    for midi_path in midi_candidates:
        if not midi_path.exists():
            continue
        try:
            midi_mod = _load_module_from_file("Song.midi_loader", midi_path)
            setattr(sys.modules["Song"], "midi_loader", midi_mod)
            break
        except Exception:
            midi_mod = None

    dual_mod = _load_module_from_file("Core_function.hand_planner_dual_path", root / "hand_planner_dual_path.py")
    setattr(sys.modules["Core_function"], "hand_planner_dual_path", dual_mod)

    seq_mod = _load_module_from_file("Core_function.sequencer", root / "sequencer.py")
    setattr(sys.modules["Core_function"], "sequencer", seq_mod)

    return {
        "note": note_mod,
        "hand_planner": hand_planner_mod,
        "hand_planner_dual_path": dual_mod,
        "sequencer": seq_mod,
        "midi_loader": midi_mod,
    }


SCRIPT_DIR = Path(__file__).resolve().parent
MODS = bootstrap_modules(SCRIPT_DIR)

note_mod = MODS["note"]
hand_planner_mod = MODS["hand_planner"]
dual_mod = MODS["hand_planner_dual_path"]
seq_mod = MODS["sequencer"]
midi_mod = MODS["midi_loader"]

HandPlanner = hand_planner_mod.HandPlanner
PlannerConfig = hand_planner_mod.PlannerConfig
Sequencer = seq_mod.Sequencer

default_dual_path_config = dual_mod.default_dual_path_config
load_and_plan_midi_dual_path = dual_mod.load_and_plan_midi_dual_path
pretty_print_dual_path_plan = dual_mod.pretty_print_dual_path_plan
plan_hand_score_dual_path = dual_mod.plan_hand_score_dual_path
note_to_angle = note_mod.note_to_angle


# ============================================================
# Planner builders
# ============================================================

def build_right_planner():
    cfg = PlannerConfig(
        note_min="C4",
        note_max="F6",
        start_center_note=None,
        start_spread=0,
        center_note_min="F4",
        center_note_max="D6",
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)


def build_left_planner():
    cfg = PlannerConfig(
        note_min="C2",
        note_max="B3",
        start_center_note="C3",
        start_spread=0,
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)


# ============================================================
# Helpers
# ============================================================

def print_score(score: dict, title: str = "RAW SCORE") -> None:
    print(f"\n{title}")
    print("=" * len(title))

    for hand_name in ("right", "left"):
        print(f"\n[{hand_name.upper()}]")
        events = score.get(hand_name, [])
        if not events:
            print("(empty)")
            continue

        for i, (notes, dur) in enumerate(events):
            print(f"[{i:02d}] notes={notes} duration={dur:.3f}s")


def find_twinkle_midi(user_path: str | None = None) -> str:
    candidates: list[Path] = []
    if user_path:
        candidates.append(Path(user_path).expanduser())

    root = _find_module_root(SCRIPT_DIR)
    candidates.extend([
        root / "Song" / "Song_list" / "twinkle-twinkle-little-star.mid",
        root / "Song_list" / "twinkle-twinkle-little-star.mid",
        root.parent / "Song" / "Song_list" / "twinkle-twinkle-little-star.mid",
        root.parent / "Song_list" / "twinkle-twinkle-little-star.mid",
        Path(r"E:\ELEC 391\code\test1\test1\Python\Song\Song_list\twinkle-twinkle-little-star.mid"),
    ])

    for path in candidates:
        if path.is_file():
            return str(path.resolve())

    raise FileNotFoundError(
        "找不到 twinkle-twinkle-little-star.mid。\n"
        "请把 MIDI 放到 Song/Song_list/ 下面，或者运行时手动传 --midi 路径。"
    )


def parse_manual_song(song_text: str) -> List[Tuple[List[str], float]]:
    out: List[Tuple[List[str], float]] = []
    parts = [x.strip() for x in song_text.split(",") if x.strip()]
    for part in parts:
        if ":" not in part:
            raise ValueError(f"坏格式: {part!r}，应该像 C4:1 或 C4/G4:0.5")

        note_part, dur_part = part.split(":", 1)
        duration = float(dur_part.strip())
        note_part = note_part.strip().upper()

        if note_part == "REST":
            notes: List[str] = []
        else:
            notes = [n.strip().upper() for n in note_part.split("/") if n.strip()]

        out.append((notes, duration))
    return out


def dual_plan_to_sequencer_input(plan: list[dict]) -> list[dict]:
    """
    Convert dual-path planned events to the old Sequencer's single-note format.

    Rules:
    - REST stays REST
    - single-note event -> keep as-is
    - multi-note event   -> keep the highest note only, and print a warning
    - path B (center_note is None) cannot be sent to old Sequencer directly
    """
    out: list[dict] = []

    for i, ev in enumerate(plan):
        notes = list(ev.get("notes", []))
        duration = float(ev.get("duration", 0.1))
        center_note = ev.get("center_note")
        spread = ev.get("spread", 0)
        note_finger_map = dict(ev.get("note_finger_map", {}))
        finger_ids = list(ev.get("finger_ids", []))

        if not notes:
            out.append({
                "note": "REST",
                "duration": duration,
                "center_note": center_note or "",
                "spread": 0 if spread is None else spread,
                "finger_id": "REST",
                "action_type": ev.get("action_type", "rest_hold"),
            })
            continue

        if center_note is None:
            raise RuntimeError(
                f"第 {i} 个事件是 Path B / half-center 事件，旧 Sequencer 不能直接执行。"
            )

        if len(notes) > 1:
            chosen = max(notes, key=lambda n: hand_planner_mod.note_to_midi(n))
            print(f"[WARN] event {i}: old Sequencer 不支持和弦，{notes} -> 只保留 {chosen}")
        else:
            chosen = notes[0]

        finger_id = note_finger_map.get(chosen)
        if not finger_id:
            finger_id = finger_ids[0] if finger_ids else "M"

        out.append({
            "note": chosen,
            "duration": duration,
            "center_note": center_note,
            "spread": 0 if spread is None else spread,
            "finger_id": finger_id,
            "action_type": ev.get("action_type", "hold_shape"),
        })

    return out


# ============================================================
# Mock serial / mock feedback
# ============================================================

class MockReader:
    def __init__(self):
        self.current_center_angle: Optional[float] = None
        self.current_spread_level: int = 0
        self.current_pressed: str = ""

    def write(self, cmd: str):
        cmd = str(cmd).strip()
        print(f"[UART] {cmd}")

        if cmd.startswith("SP="):
            m = re.match(r"SP=([-+]?\d+(?:\.\d+)?)!", cmd)
            if m:
                self.current_center_angle = float(m.group(1))
            return

        if cmd.startswith("SF="):
            m = re.match(r"SF=(\d+)!", cmd)
            if m:
                self.current_spread_level = int(m.group(1))
            return

        if cmd.startswith("SL="):
            m = re.match(r"SL=([0-9]+)!", cmd)
            if m:
                self.current_pressed = m.group(1)
            return

        if cmd.startswith("RE=1!"):
            self.current_center_angle = None
            self.current_spread_level = 0
            self.current_pressed = ""
            return

    def get_actual_center(self):
        return self.current_center_angle

    def get_actual_spread_angle(self):
        step = getattr(seq_mod, "SPREAD_STEP_DEG", 60.0)
        return float(self.current_spread_level) * float(step)


def drain_queue(out_q: queue.Queue):
    while True:
        try:
            tag, payload = out_q.get_nowait()
        except queue.Empty:
            break

        if tag in {
            "seq_started",
            "seq_home_start",
            "seq_home_done",
            "seq_note",
            "seq_move_time",
            "seq_press",
            "seq_release",
            "seq_done",
            "error",
            "seq_stop",
        }:
            print(f"[Q] {tag}: {payload}")


# ============================================================
# Sequencer runner
# ============================================================

def run_right_hand_sequencer(planned_right: list[dict]) -> None:
    seq_input = dual_plan_to_sequencer_input(planned_right)

    print("\nRIGHT INPUT TO OLD SEQUENCER")
    print("============================")
    for i, ev in enumerate(seq_input):
        print(f"[{i:02d}] {ev}")

    # Make test faster
    seq_mod.HOME_WAIT_S = 0.15
    seq_mod.SPREAD_SETTLE_S = 0.01
    seq_mod.CENTER_WAIT_S = 0.5
    seq_mod.SPREAD_WAIT_S = 0.2

    reader = MockReader()
    out_q: queue.Queue = queue.Queue()
    stop_evt = threading.Event()
    pause_evt = threading.Event()

    seq = Sequencer(
        planned_song=seq_input,
        reader=reader,
        out_q=out_q,
        stop_evt=stop_evt,
        pause_evt=pause_evt,
        get_actual_fn=reader.get_actual_center,
        get_actual_spread_fn=reader.get_actual_spread_angle,
    )

    seq.start()

    while seq.is_alive():
        drain_queue(out_q)
        time.sleep(0.02)

    seq.join(timeout=1.0)
    drain_queue(out_q)

    print("\nFINAL MOCK STATE")
    print("================")
    print("center_angle =", reader.current_center_angle)
    print("spread_level =", reader.current_spread_level)
    print("pressed      =", reader.current_pressed)


# ============================================================
# Main
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(description="Right-hand planner + Sequencer test runner")
    parser.add_argument("--midi", type=str, default=None,
                        help="Optional MIDI path. If omitted and no manual song is given, auto-search twinkle MIDI.")
    parser.add_argument("--manual-song", type=str, default=None,
                        help='Manual right-hand song, e.g. "C4:1,C4:1" or "C5:1,C4:1"')
    parser.add_argument("--min-duration", type=float, default=0.08,
                        help="Minimum kept note duration when loading MIDI.")
    parser.add_argument("--split-note", type=str, default="C4",
                        help='Split threshold when MIDI is single-track. Default: "C4"')
    parser.add_argument("--verbose-midi", action="store_true", help="Print MIDI track analysis.")
    parser.add_argument("--no-sequencer", action="store_true", help="Only plan and print; do not run mock Sequencer.")
    args = parser.parse_args()

    print("RUNNING FILE =", __file__)

    dual_cfg = default_dual_path_config()
    right_planner = build_right_planner()
    left_planner = build_left_planner()

    if args.manual_song:
        print("\nUSING MANUAL RIGHT-HAND SONG")
        print("===========================")
        print(args.manual_song)

        right_score = parse_manual_song(args.manual_song)
        raw_score = {"right": right_score, "left": []}

        planned_right = plan_hand_score_dual_path(
            score_events=right_score,
            planner=right_planner,
            hand_name="right",
            dual_cfg=dual_cfg,
            note_to_angle_fn=note_to_angle,
        )
        planned = {"right": planned_right, "left": []}
    else:
        midi_path = find_twinkle_midi(args.midi)

        print("\nUSING MIDI")
        print("==========")
        print(midi_path)

        if midi_mod is None:
            raise RuntimeError("当前环境下没有可用的 midi_loader.py")

        result = load_and_plan_midi_dual_path(
            path=midi_path,
            right_planner=right_planner,
            left_planner=left_planner,
            dual_cfg=dual_cfg,
            note_to_angle_fn=note_to_angle,
            min_duration=args.min_duration,
            split_note=args.split_note,
            verbose=args.verbose_midi,
        )

        raw_score = result["raw_score"]
        planned = result["planned"]
        planned_right = planned["right"]

    print_score(raw_score, "INPUT SCORE")
    pretty_print_dual_path_plan(planned["right"], "RIGHT DUAL PATH PLAN")

    if not args.no_sequencer:
        run_right_hand_sequencer(planned_right)


if __name__ == "__main__":
    main()
