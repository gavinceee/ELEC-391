# Core_function/sequencer.py
import threading
import time
from Core_function.note import note_to_angle

CENTER_TOL_DEG = 15.0
CENTER_WAIT_S = 5

# Small motor / spread
SPREAD_SETTLE_S = 0.08      # fallback open-loop settle time
SPREAD_WAIT_S = 1.2       # feedback wait timeout
SPREAD_TOL_DEG = 12.0       # actualAngle2 tolerance
SPREAD_STEP_DEG = 80      # spread 0/1/2 -> 0/75/150 deg

MIN_RELEASE_GAP_S = 0.03
HOME_WAIT_S = 4.5

# Preload config
PRELOAD_ENABLE = True
PRELOAD_ALLOWED_CURRENT_FINGER = "M"
PRELOAD_ALLOWED_NEXT_FINGERS = {"Rw", "Rb", "Lw", "Lb"}

PRELOAD_AFTER_PRESS_MIN_S = 0.06
PRELOAD_REMAIN_MIN_S = 0.10
PRELOAD_TRIGGER_RATIO = 0.55

FINGER_TO_SOLENOID = {
    "Lw": 1,
    "Lb": 2,
    "M": 3,
    "Rb": 4,
    "Rw": 5,
}


class Sequencer(threading.Thread):
    """
    Preferred input format (planned_song):
        [
            {
                "note": "G4",
                "duration": 0.40,
                "center_note": "C4",
                "spread": 2,
                "finger_id": "Rw",
                "action_type": "finger_only",
            },
            ...
        ]

    Legacy input format (song):
        [
            ("C4", 0.40),
            ("G4", 0.40),
            ...
        ]
    Legacy format will be auto-converted to a simple single-note plan.

    Hardware command mapping:
        SP=<angle>!    -> big hand / center motor
        SF=<spread>!   -> small motor / spread level
        SL=1! / SL=0!  -> press / release
        RE=1!          -> home
    """

    def __init__(
        self,
        planned_song=None,
        reader=None,
        out_q=None,
        stop_evt=None,
        pause_evt=None,
        get_actual_fn=None,
        get_actual_spread_fn=None,
        song=None,
    ):
        super().__init__(daemon=True)

        # Backward compatibility:
        # old style might call Sequencer(song=..., ...)
        if planned_song is None:
            planned_song = song

        # very old style:
        # Sequencer(planned_song, reader, out_q, stop_evt, get_actual_fn)
        if get_actual_fn is None and callable(pause_evt):
            get_actual_fn = pause_evt
            pause_evt = None

        self.planned_song = self._normalize_song_input(planned_song or [])
        self.reader = reader
        self.out_q = out_q
        self.stop_evt = stop_evt if stop_evt is not None else threading.Event()
        self.pause_evt = pause_evt if pause_evt is not None else threading.Event()

        self.get_actual_fn = get_actual_fn if get_actual_fn is not None else (lambda: None)
        self.get_actual_spread_fn = (
            get_actual_spread_fn if get_actual_spread_fn is not None else (lambda: None)
        )

        self._pause_notified = False
        self._pause_release_sent = False

        # confirmed-ready state
        self._last_center_note = None
        self._last_spread = None

        # pending spread motion
        self._pending_spread_target = None
        self._pending_spread_sent_at = None

    # --------------------------------------------------------
    # Input normalization
    # --------------------------------------------------------
    def _normalize_song_input(self, seq):
        out = []
        for ev in seq:
            # Preferred dict event
            if isinstance(ev, dict):
                note = self._norm_note(ev.get("note", "REST"))
                duration = self._safe_duration(ev.get("duration", 0.1))
                center_note = self._norm_note(ev.get("center_note", ""))
                spread = self._safe_int(ev.get("spread", 0), default=0)
                finger_id = self._norm_finger(ev.get("finger_id", "REST"))
                action_type = str(ev.get("action_type", "hold_shape"))

                out.append({
                    "note": note,
                    "duration": duration,
                    "center_note": center_note,
                    "spread": spread,
                    "finger_id": finger_id,
                    "action_type": action_type,
                })
                continue

            # Legacy tuple/list event: (note, duration)
            if isinstance(ev, (tuple, list)) and len(ev) >= 2:
                note = self._norm_note(ev[0])
                duration = self._safe_duration(ev[1])

                # simple compatibility fallback:
                # center_note = note itself, spread = 0, finger = M
                center_note = "" if note == "REST" else note
                out.append({
                    "note": note,
                    "duration": duration,
                    "center_note": center_note,
                    "spread": 0,
                    "finger_id": "M" if note != "REST" else "REST",
                    "action_type": "legacy_raw",
                })
                continue

            # unknown event -> ignore
        return out

    # --------------------------------------------------------
    # Serial helpers
    # --------------------------------------------------------
    def _write_cmd(self, cmd: str):
        self.reader.write(cmd)

    def _send_center(self, center_note: str) -> float:
        angle = note_to_angle(center_note)
        self._write_cmd(f"SP={angle:.2f}!")
        return angle

    def _send_spread_cmd(self, spread: int):
        self._write_cmd(f"SF={int(spread)}!")

    def _finger_to_solenoid(self, finger_id: str) -> int:
        fid = self._norm_finger(finger_id)
        if fid not in FINGER_TO_SOLENOID:
            raise ValueError(f"Unsupported finger_id for solenoid binding: {fid}")
        return FINGER_TO_SOLENOID[fid]

    def _press_finger(self, finger_id: str) -> int:
        sl = self._finger_to_solenoid(finger_id)
        self._write_cmd(f"SL={sl}!")
        return sl

    def _start_spread_motion(self, spread: int):
        """
        Start / restart spread motion.
        This only means "motion started", not "already ready".
        """
        spread = int(spread)
        self._send_spread_cmd(spread)
        self._pending_spread_target = spread
        self._pending_spread_sent_at = time.perf_counter()

    def _spread_target_angle(self, spread: int) -> float:
        return float(int(spread)) * SPREAD_STEP_DEG

    def _spread_remaining_wait_s(self) -> float:
        if self._pending_spread_target is None or self._pending_spread_sent_at is None:
            return 0.0

        elapsed = time.perf_counter() - self._pending_spread_sent_at
        remain = SPREAD_SETTLE_S - elapsed
        return max(0.0, remain)

    def _finalize_spread_ready(self, spread=None):
        """
        Only after ready is confirmed do we mark spread as ready.
        """
        if spread is not None:
            self._last_spread = int(spread)
        elif self._pending_spread_target is not None:
            self._last_spread = self._pending_spread_target

        self._pending_spread_target = None
        self._pending_spread_sent_at = None

    # --------------------------------------------------------
    # Small helpers
    # --------------------------------------------------------
    def _safe_duration(self, duration) -> float:
        try:
            d = float(duration)
        except (TypeError, ValueError):
            d = 0.0
        return max(0.01, d)

    def _safe_int(self, x, default=0) -> int:
        try:
            return int(x)
        except Exception:
            return int(default)

    def _norm_note(self, x) -> str:
        s = str("" if x is None else x).strip().upper()
        if s == "":
            return ""
        return s

    def _norm_finger(self, x) -> str:
        return str("REST" if x is None else x).strip()

    # --------------------------------------------------------
    # Timing / pause helpers
    # --------------------------------------------------------
    def _elapsed(self, song_t0: float, paused_accum: float) -> float:
        return max(0.0, time.perf_counter() - song_t0 - paused_accum)

    def _handle_pause(self, song_t0: float, paused_accum: float):
        """
        While paused:
        - freeze sequence time
        - send seq_paused / seq_resumed
        - send SL=0! once for safety
        Returns updated paused_accum, or None if stopped.
        """
        if not self.pause_evt.is_set():
            self._pause_notified = False
            self._pause_release_sent = False
            return paused_accum

        pause_start = time.perf_counter()

        if not self._pause_notified:
            paused_at = self._elapsed(song_t0, paused_accum)
            self.out_q.put(("seq_paused", {"elapsed": paused_at}))
            self._pause_notified = True

        if not self._pause_release_sent:
            try:
                self._write_cmd("SL=0!")
            except Exception:
                pass
            self._pause_release_sent = True

        frozen_elapsed = self._elapsed(song_t0, paused_accum)

        while self.pause_evt.is_set() and not self.stop_evt.is_set():
            self.out_q.put(("seq_time", frozen_elapsed))
            time.sleep(0.02)

        if self.stop_evt.is_set():
            return None

        paused_for = time.perf_counter() - pause_start
        paused_accum += paused_for
        resumed_at = self._elapsed(song_t0, paused_accum)

        self.out_q.put(("seq_resumed", {
            "elapsed": resumed_at,
            "paused_for": paused_for,
        }))

        self._pause_notified = False
        self._pause_release_sent = False
        return paused_accum

    def _sleep_for(self, seconds: float, song_t0: float, paused_accum: float):
        """
        Pause-aware sleep.
        Returns:
            (ok: bool, paused_accum: float)
        """
        try:
            seconds = float(seconds)
        except (TypeError, ValueError):
            seconds = 0.0

        seconds = max(0.0, seconds)
        active_elapsed = 0.0
        t0 = time.perf_counter()

        while not self.stop_evt.is_set():
            updated = self._handle_pause(song_t0, paused_accum)
            if updated is None:
                return False, paused_accum
            paused_accum = updated

            now = time.perf_counter()
            dt = now - t0
            t0 = now
            active_elapsed += dt

            self.out_q.put(("seq_time", self._elapsed(song_t0, paused_accum)))

            if active_elapsed >= seconds:
                return True, paused_accum

            time.sleep(0.005)

        return False, paused_accum

    # --------------------------------------------------------
    # Center wait
    # --------------------------------------------------------
    def _wait_until_center(self, target_angle: float, tol_deg: float, timeout_s: float,
                           song_t0: float, paused_accum: float):
        """
        Wait until big hand center position is close enough.
        Returns:
            (reached: bool, actual_angle: float|None, paused_accum: float)
        """
        try:
            timeout_s = float(timeout_s)
        except (TypeError, ValueError):
            timeout_s = 0.0

        timeout_s = max(0.0, timeout_s)
        active_wait = 0.0
        t0 = time.perf_counter()
        last_actual = None

        while not self.stop_evt.is_set():
            updated = self._handle_pause(song_t0, paused_accum)
            if updated is None:
                return False, last_actual, paused_accum
            paused_accum = updated

            now = time.perf_counter()
            dt = now - t0
            t0 = now
            active_wait += dt

            self.out_q.put(("seq_time", self._elapsed(song_t0, paused_accum)))

            actual = self.get_actual_fn()
            if actual is not None:
                last_actual = actual
                if abs(actual - target_angle) <= tol_deg:
                    return True, actual, paused_accum

            if active_wait >= timeout_s:
                return False, last_actual, paused_accum

            time.sleep(0.005)

        return False, last_actual, paused_accum

    # --------------------------------------------------------
    # Spread ready logic
    # --------------------------------------------------------
    def _spread_ready_now(self, target_spread: int):
        """
        Returns:
            (ready: bool, actual_spread_angle: float|None)
        """
        target_spread = int(target_spread)

        # Preferred: real feedback
        try:
            actual = self.get_actual_spread_fn()
        except Exception:
            actual = None

        if actual is not None:
            target_angle = self._spread_target_angle(target_spread)
            if abs(actual - target_angle) <= SPREAD_TOL_DEG:
                return True, actual
            return False, actual

        # Fallback: open-loop timing estimate
        if self._pending_spread_target == target_spread:
            remain = self._spread_remaining_wait_s()
            if remain <= 0.0:
                return True, None
            return False, None

        if self._last_spread == target_spread:
            return True, None

        return False, None

    def _wait_until_spread_ready(self, target_spread: int, timeout_s: float,
                                 song_t0: float, paused_accum: float):
        """
        Wait until small motor spread is ready.
        If actual spread feedback exists -> wait by actualAngle2
        Else -> fallback to timing estimate
        Returns:
            (ready: bool, actual_spread_angle: float|None, paused_accum: float)
        """
        target_spread = int(target_spread)

        # feedback mode
        try:
            probe = self.get_actual_spread_fn()
        except Exception:
            probe = None

        if probe is not None:
            try:
                timeout_s = float(timeout_s)
            except (TypeError, ValueError):
                timeout_s = 0.0

            timeout_s = max(0.0, timeout_s)
            active_wait = 0.0
            t0 = time.perf_counter()
            last_actual = probe

            while not self.stop_evt.is_set():
                updated = self._handle_pause(song_t0, paused_accum)
                if updated is None:
                    return False, last_actual, paused_accum
                paused_accum = updated

                now = time.perf_counter()
                dt = now - t0
                t0 = now
                active_wait += dt

                self.out_q.put(("seq_time", self._elapsed(song_t0, paused_accum)))

                try:
                    actual = self.get_actual_spread_fn()
                except Exception:
                    actual = None

                if actual is not None:
                    last_actual = actual
                    if abs(actual - self._spread_target_angle(target_spread)) <= SPREAD_TOL_DEG:
                        self._finalize_spread_ready(target_spread)
                        return True, actual, paused_accum

                if active_wait >= timeout_s:
                    return False, last_actual, paused_accum

                time.sleep(0.005)

            return False, last_actual, paused_accum

        # fallback open-loop
        if self._pending_spread_target is None:
            return True, None, paused_accum

        remain = self._spread_remaining_wait_s()
        if remain > 0.0:
            ok, paused_accum = self._sleep_for(remain, song_t0, paused_accum)
            if not ok:
                return False, None, paused_accum

        self._finalize_spread_ready(target_spread)
        return True, None, paused_accum

    def _ensure_spread_ready(self, target_spread: int, song_t0: float, paused_accum: float):
        """
        Make sure requested spread is actually ready before pressing.
        Logic:
            A) already ready -> skip
            B) pending same target -> wait until ready
            C) not started -> start motion and wait
            D) if first wait failed -> reissue once and wait again
        Returns:
            (ok: bool, actual_spread_angle: float|None, paused_accum: float)
        """
        target_spread = int(target_spread)

        ready, actual = self._spread_ready_now(target_spread)
        if ready:
            self._finalize_spread_ready(target_spread)
            return True, actual, paused_accum

        if self._pending_spread_target != target_spread:
            try:
                self._start_spread_motion(target_spread)
            except Exception:
                return False, None, paused_accum

        ok, actual, paused_accum = self._wait_until_spread_ready(
            target_spread=target_spread,
            timeout_s=SPREAD_WAIT_S,
            song_t0=song_t0,
            paused_accum=paused_accum,
        )
        if ok:
            return True, actual, paused_accum

        # one retry
        try:
            self._start_spread_motion(target_spread)
        except Exception:
            return False, actual, paused_accum

        ok, actual, paused_accum = self._wait_until_spread_ready(
            target_spread=target_spread,
            timeout_s=SPREAD_WAIT_S,
            song_t0=song_t0,
            paused_accum=paused_accum,
        )
        return ok, actual, paused_accum

    # --------------------------------------------------------
    # Preload helper
    # --------------------------------------------------------
    def _build_preload_plan(self, idx: int):
        """
        Allow preload only when:
            current note:
                - not REST
                - finger_id == "M"
            next note:
                - not REST
                - finger_id in {"Rw", "Lw"}
                - same center_note
                - different spread

        Preload means:
            during current hold, start next spread motion early.
            It does NOT mean next spread is already confirmed ready.
        """
        if not PRELOAD_ENABLE:
            return None

        if idx < 0 or idx >= len(self.planned_song) - 1:
            return None

        cur_ev = self.planned_song[idx]
        next_ev = self.planned_song[idx + 1]

        cur_note = self._norm_note(cur_ev.get("note", "REST"))
        next_note = self._norm_note(next_ev.get("note", "REST"))

        if cur_note == "REST" or next_note == "REST":
            return None

        cur_finger = self._norm_finger(cur_ev.get("finger_id", "REST"))
        next_finger = self._norm_finger(next_ev.get("finger_id", "REST"))

        if cur_finger != PRELOAD_ALLOWED_CURRENT_FINGER:
            return None

        if next_finger not in PRELOAD_ALLOWED_NEXT_FINGERS:
            return None

        cur_center = self._norm_note(cur_ev.get("center_note", ""))
        next_center = self._norm_note(next_ev.get("center_note", ""))

        if not cur_center or not next_center or cur_center != next_center:
            return None

        try:
            cur_spread = int(cur_ev.get("spread", 0))
            next_spread = int(next_ev.get("spread", 0))
        except Exception:
            return None

        if next_spread == cur_spread:
            return None

        duration = self._safe_duration(cur_ev.get("duration", 0.1))

        if duration <= (PRELOAD_AFTER_PRESS_MIN_S + PRELOAD_REMAIN_MIN_S):
            return None

        delay_before_preload = max(
            PRELOAD_AFTER_PRESS_MIN_S,
            duration * PRELOAD_TRIGGER_RATIO
        )
        delay_before_preload = min(
            delay_before_preload,
            duration - PRELOAD_REMAIN_MIN_S
        )

        if delay_before_preload <= 0.0:
            return None

        remaining_after_preload = duration - delay_before_preload
        if remaining_after_preload < PRELOAD_REMAIN_MIN_S:
            return None

        return {
            "next_idx": idx + 1,
            "during_note": cur_note,
            "during_finger_id": cur_finger,
            "center_note": cur_center,
            "from_spread": cur_spread,
            "to_spread": next_spread,
            "next_note": next_note,
            "next_finger_id": next_finger,
            "delay_before_preload_s": delay_before_preload,
            "remaining_after_preload_s": remaining_after_preload,
        }

    # --------------------------------------------------------
    # Main run
    # --------------------------------------------------------
    def run(self):
        total = len(self.planned_song)
        self.out_q.put(("seq_started", {"total": total, "song": self.planned_song}))

        # -------------------------
        # Auto-home before playback
        # -------------------------
        try:
            self.out_q.put(("seq_home_start", None))
            self.out_q.put(("status", "[Sequencer] Auto homing..."))
            self._write_cmd("RE=1!")
        except Exception as e:
            self.out_q.put(("error", f"[Sequencer] Failed to send RE=1!: {e}"))
            self.out_q.put(("seq_stop", {"elapsed": 0.0}))
            return

        home_t0 = time.perf_counter()
        while not self.stop_evt.is_set():
            if time.perf_counter() - home_t0 >= HOME_WAIT_S:
                break
            time.sleep(0.01)

        if self.stop_evt.is_set():
            self.out_q.put(("seq_stop", {"elapsed": 0.0}))
            return

        try:
            # reset spread after home
            self._start_spread_motion(0)
            if self.get_actual_spread_fn() is not None:
                ok, _, _ = self._wait_until_spread_ready(
                    target_spread=0,
                    timeout_s=SPREAD_WAIT_S,
                    song_t0=time.perf_counter(),
                    paused_accum=0.0,
                )
                if ok:
                    self._finalize_spread_ready(0)
            else:
                time.sleep(SPREAD_SETTLE_S)
                self._finalize_spread_ready(0)
        except Exception:
            pass

        home_elapsed = max(0.0, time.perf_counter() - home_t0)
        self.out_q.put(("seq_home_done", {"elapsed": home_elapsed}))

        # -------------------------
        # Real song timing starts here
        # -------------------------
        song_t0 = time.perf_counter()
        paused_accum = 0.0

        for idx, ev in enumerate(self.planned_song):
            if self.stop_evt.is_set():
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return

            updated = self._handle_pause(song_t0, paused_accum)
            if updated is None:
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return
            paused_accum = updated

            note = self._norm_note(ev.get("note", "REST"))
            duration = self._safe_duration(ev.get("duration", 0.1))
            center_note = self._norm_note(ev.get("center_note", ""))
            spread = self._safe_int(ev.get("spread", 0), default=0)
            finger_id = self._norm_finger(ev.get("finger_id", "REST"))
            action_type = str(ev.get("action_type", "hold_shape"))

            is_rest = (note == "REST")

            self.out_q.put(("seq_note", {
                "idx": idx,
                "total": total,
                "note": note,
                "center_note": center_note,
                "spread": spread,
                "finger_id": finger_id,
                "action_type": action_type,
            }))

            # -------------------------
            # Step 1: center ready
            # -------------------------
            target_center_angle = None
            actual_after_move = None
            center_reached = True

            need_center_move = (
                center_note and
                center_note != self._last_center_note
            )

            if need_center_move:
                try:
                    target_center_angle = self._send_center(center_note)
                except Exception as e:
                    self.out_q.put(("error", f"[Sequencer] Failed to send center move: {e}"))
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return

                center_reached, actual_after_move, paused_accum = self._wait_until_center(
                    target_angle=target_center_angle,
                    tol_deg=CENTER_TOL_DEG,
                    timeout_s=CENTER_WAIT_S,
                    song_t0=song_t0,
                    paused_accum=paused_accum,
                )

                move_started_at = time.perf_counter()

                center_reached, actual_after_move, paused_accum = self._wait_until_center(
                    target_angle=target_center_angle,
                    tol_deg=CENTER_TOL_DEG,
                    timeout_s=CENTER_WAIT_S,
                    song_t0=song_t0,
                    paused_accum=paused_accum,
                )

                move_time = time.perf_counter() - move_started_at

                self.out_q.put(("seq_move_time", {
                    "idx": idx,
                    "note": note,
                    "center_note": center_note,
                    "target_angle": target_center_angle,
                    "actual_angle": actual_after_move,
                    "reached": center_reached,
                    "move_time": move_time,
                }))

                if not center_reached:
                    self.out_q.put(("error", f"[Sequencer] Center timeout on {center_note}"))
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return

                self._last_center_note = center_note

            # -------------------------
            # Step 1: spread ready
            # -------------------------
            spread_ok, _, paused_accum = self._ensure_spread_ready(
                target_spread=spread,
                song_t0=song_t0,
                paused_accum=paused_accum,
            )
            if not spread_ok:
                self.out_q.put(("error", f"[Sequencer] Spread not ready on level {spread}"))
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return

            # -------------------------
            # REST: reposition + wait only
            # -------------------------
            if is_rest:
                ok, paused_accum = self._sleep_for(duration, song_t0, paused_accum)
                if not ok:
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return
                continue

            # -------------------------
            # Step 2: press
            # -------------------------
            try:
                sl = self._press_finger(finger_id)
                press_elapsed = self._elapsed(song_t0, paused_accum)
                self.out_q.put(("seq_press", {
                    "idx": idx,
                    "note": note,
                    "finger_id": finger_id,
                    "solenoid": sl,
                    "elapsed": press_elapsed,
                }))
            except Exception as e:
                self.out_q.put(("error", f"[Sequencer] Failed to press finger {finger_id}: {e}"))
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return

            # -------------------------
            # Step 3: hold + optional preload
            # -------------------------
            preload_plan = self._build_preload_plan(idx)

            if preload_plan is not None:
                # hold first part
                ok, paused_accum = self._sleep_for(
                    preload_plan["delay_before_preload_s"],
                    song_t0,
                    paused_accum
                )
                if not ok:
                    try:
                        self._write_cmd("SL=0!")
                    except Exception:
                        pass
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return

                # preload next spread
                try:
                    if self._pending_spread_target != preload_plan["to_spread"]:
                        self._start_spread_motion(preload_plan["to_spread"])

                    self.out_q.put(("seq_preload", {
                        "idx": idx,
                        "during_note": preload_plan["during_note"],
                        "during_finger_id": preload_plan["during_finger_id"],
                        "center_note": preload_plan["center_note"],
                        "from_spread": preload_plan["from_spread"],
                        "to_spread": preload_plan["to_spread"],
                        "next_idx": preload_plan["next_idx"],
                        "next_note": preload_plan["next_note"],
                        "next_finger_id": preload_plan["next_finger_id"],
                        "elapsed": self._elapsed(song_t0, paused_accum),
                    }))
                except Exception as e:
                    self.out_q.put(("error", f"[Sequencer] Failed to preload spread: {e}"))
                    try:
                        self._write_cmd("SL=0!")
                    except Exception:
                        pass
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return

                # hold second part
                ok, paused_accum = self._sleep_for(
                    preload_plan["remaining_after_preload_s"],
                    song_t0,
                    paused_accum
                )
                if not ok:
                    try:
                        self._write_cmd("SL=0!")
                    except Exception:
                        pass
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return
            else:
                ok, paused_accum = self._sleep_for(duration, song_t0, paused_accum)
                if not ok:
                    try:
                        self._write_cmd("SL=0!")
                    except Exception:
                        pass
                    self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                    return

            # -------------------------
            # Step 4: release
            # -------------------------
            try:
                self._write_cmd("SL=0!")
                release_elapsed = self._elapsed(song_t0, paused_accum)
                self.out_q.put(("seq_release", {
                    "idx": idx,
                    "note": note,
                    "finger_id": finger_id,
                    "elapsed": release_elapsed,
                }))
            except Exception as e:
                self.out_q.put(("error", f"[Sequencer] Failed to send SL=0!: {e}"))
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return

            ok, paused_accum = self._sleep_for(MIN_RELEASE_GAP_S, song_t0, paused_accum)
            if not ok:
                self.out_q.put(("seq_stop", {"elapsed": self._elapsed(song_t0, paused_accum)}))
                return

        final_elapsed = self._elapsed(song_t0, paused_accum)
        self.out_q.put(("seq_time", final_elapsed))
        self.out_q.put(("seq_done", {"elapsed": final_elapsed}))