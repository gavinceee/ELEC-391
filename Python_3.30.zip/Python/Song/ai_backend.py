import os
import json
from openai import OpenAI


def ask_ai_for_song(query: str) -> dict:
    api_key = "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"
    print("KEY HEAD:", api_key[:12] if api_key else "(empty)")
    
    if not api_key:
        print("❌ No API key -> random fallback")
        return {"mode": "random"}

    print("✅ API KEY loaded")

    client = OpenAI(api_key=api_key)

    prompt = f"""
You are a music search helper for a piano robot.

User query:
{query}

Your job:
1. If the query looks like a partial, misspelled, or fuzzy song/piano piece title, return mode="suggest".
2. If the query clearly does NOT look like a song title, return mode="random".
3. Only return mode="melody" if the query clearly asks for a song or piano piece and no better suggestion is needed.

Important rules:
- For short partial inputs like "merry c", "happy b", "twink", prefer mode="suggest"
- Try to infer likely song names from common songs
- Do NOT jump to random unless the query is truly nonsense
- If melody is generated, it must be monophonic, notes E3-E5 only, durations 0.12-1.50 sec

Return JSON only in exactly one of these forms:

{{
  "mode": "suggest",
  "suggestions": ["Song A", "Song B", "Song C"]
}}

{{
  "mode": "random"
}}

{{
  "mode": "melody",
  "title": "Some Song",
  "song": [
    {{"note": "C4", "duration": 0.5}},
    {{"note": "E4", "duration": 0.5}},
    {{"note": "G4", "duration": 1.0}}
  ]
}}
"""

    try:
        response = client.responses.create(
            model="gpt-5.4-mini",
            input=prompt,
            text={"format": {"type": "json_object"}}
        )
    except Exception as e:
        print("❌ API call failed:", e)
        return {"mode": "random"}

    try:
        raw = response.output_text
        print("🔍 AI RAW RESPONSE:", raw)

        data = json.loads(raw)
        print("✅ AI PARSED:", data)
    except Exception as e:
        print("❌ JSON parse failed:", e)
        return {"mode": "random"}

    if not isinstance(data, dict):
        return {"mode": "random"}

    mode = str(data.get("mode", "")).strip().lower()

    if mode == "suggest":
        suggestions = data.get("suggestions", [])
        if isinstance(suggestions, list):
            cleaned = []
            for s in suggestions[:5]:
                s = str(s).strip()
                if s and s not in cleaned:
                    cleaned.append(s)
            if cleaned:
                return {"mode": "suggest", "suggestions": cleaned}

    if mode == "melody":
        title = str(data.get("title", "(AI Melody)")).strip() or "(AI Melody)"
        items = data.get("song", [])
        if isinstance(items, list):
            song = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                note = str(item.get("note", "")).strip().upper()
                try:
                    dur = float(item.get("duration", 0.5))
                except Exception:
                    dur = 0.5
                if note:
                    song.append((note, dur))
            if song:
                return {
                    "mode": "melody",
                    "title": title,
                    "song": song,
                }

    return {"mode": "random"}

def generate_song_notes_from_title(title: str) -> dict:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return {"mode": "random"}

    client = OpenAI(api_key=api_key)

    prompt = f"""
You are generating a playable melody for a piano robot.

Song title:
{title}

Robot constraints:
- monophonic melody only
- no chords
- notes must be only between E3 and E5
- each note duration must be between 0.12 and 1.50 seconds
- output only a simple recognizable melody
- target total length around 30 to 90 seconds
- use REST when needed

Return JSON only in exactly this format:

{{
  "mode": "melody",
  "title": "{title}",
  "song": [
    {{"note": "C4", "duration": 0.5}},
    {{"note": "E4", "duration": 0.5}},
    {{"note": "G4", "duration": 1.0}},
    {{"note": "REST", "duration": 0.25}}
  ]
}}
"""

    try:
        response = client.responses.create(
            model="gpt-4.1-mini",
            input=prompt,
            text={"format": {"type": "json_object"}}
        )
    except Exception as e:
        print("❌ melody generation failed:", e)
        return {"mode": "random"}

    try:
        raw = response.output_text
        print("🔍 MELODY RAW:", raw)
        data = json.loads(raw)
    except Exception as e:
        print("❌ melody parse failed:", e)
        return {"mode": "random"}

    if not isinstance(data, dict):
        return {"mode": "random"}

    if str(data.get("mode", "")).strip().lower() != "melody":
        return {"mode": "random"}

    title_out = str(data.get("title", title)).strip() or title
    items = data.get("song", [])
    if not isinstance(items, list):
        return {"mode": "random"}

    song = []
    for item in items:
        if not isinstance(item, dict):
            continue
        note = str(item.get("note", "")).strip().upper()
        try:
            dur = float(item.get("duration", 0.5))
        except Exception:
            dur = 0.5
        if note:
            song.append((note, dur))

    if not song:
        return {"mode": "random"}

    return {
        "mode": "melody",
        "title": title_out,
        "song": song,
    }