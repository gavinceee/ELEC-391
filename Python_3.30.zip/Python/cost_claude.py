"""
Piano-Playing Robot — Sequencing & Optimisation Algorithm
==========================================================
Reads a music score and produces the optimal sequence of SP, FM, SL commands
that minimises total motor travel cost across the whole piece.

Cost function:
    motor A: 0 if no move, else a + 5 * |ΔSP|
    motor B: b * |ΔFM|

Default:
    a = 3
    b = 1
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# 1.  KEY / DEGREE DEFINITIONS
# ---------------------------------------------------------------------------

# White keys in order across the playable range
WHITE_KEYS = [
    "E3", "F3", "G3", "A3", "B3",
    "C4", "D4", "E4", "F4", "G4", "A4", "B4",
    "C5", "D5", "E5",
]

# All keys with their degrees (from spec §4.3, used as ground-truth reference)
KEY_DEGREES: dict[str, float] = {
    "E3": 1530.00, "F3": 1471.29, "F#3": 1412.58,
    "G3": 1353.87, "G#3": 1295.16, "A3": 1236.45,
    "A#3": 1177.74, "B3": 1119.03,
    "C4": 1060.32, "C#4": 1001.61, "D4": 942.90,
    "D#4": 884.19, "E4": 825.48, "F4": 766.77,
    "F#4": 708.06, "G4": 649.35, "G#4": 590.64,
    "A4": 531.93, "A#4": 473.22, "B4": 414.51,
    "C5": 355.80, "C#5": 297.09, "D5": 238.38,
    "D#5": 179.67, "E5": 121.00,
}

# Spacing constants (§4.2)
WHITE_SPACING = 60.0   # degrees per white key
BLACK_SPACING = 30.0   # degrees per black key (offset from adjacent white)


def is_black(note: str) -> bool:
    return "#" in note or "b" in note  # only sharps used in this spec


def is_white(note: str) -> bool:
    return not is_black(note)


# Playable range guards
MIN_DEGREE = KEY_DEGREES["E5"]   # numerically smallest (rightmost key)
MAX_DEGREE = KEY_DEGREES["E3"]   # numerically largest  (leftmost key)


def in_range(degree: float) -> bool:
    return MIN_DEGREE <= degree <= MAX_DEGREE


# ---------------------------------------------------------------------------
# 2.  FM / SPREAD MODEL
# ---------------------------------------------------------------------------
# Anchor SP = C4 (finger 3 at C4 = 1060.32°)
# FM=0:  F1=A3(1236.45), F2=A#3(1177.74), F3=C4(1060.32), F4=D#4(884.19), F5=E4(825.48)
# FM=120: F1=F3(1471.29), F2=F#3(1412.58), F3=C4(1060.32), F4=F#4(708.06), F5=G4(649.35)
#
# Offsets relative to F3 anchor (positive = left = higher degree value):
#   Finger 1: FM=0 → +176.13,  FM=120 → +410.97
#   Finger 5: FM=0 → -234.84,  FM=120 → -411.00  (approx from spec)
#
# We store the offset-per-FM-unit for fingers 1 and 5, then derive 2 and 4.

C4_DEG = KEY_DEGREES["C4"]

# Finger 1 offset from F3 at FM=0 and FM=120
F1_OFFSET_FM0 = KEY_DEGREES["A3"] - C4_DEG
F1_OFFSET_FM120 = KEY_DEGREES["F3"] - C4_DEG

# Finger 5 offset from F3 at FM=0 and FM=120
F5_OFFSET_FM0 = KEY_DEGREES["E4"] - C4_DEG
F5_OFFSET_FM120 = KEY_DEGREES["G4"] - C4_DEG


def finger_offset(finger: int, fm: float) -> float:
    """
    Return the degree offset of <finger> relative to finger 3 (SP anchor),
    for a given FM value. Positive offset = left on keyboard (higher degree).
    """
    t = fm / 120.0  # 0..1

    if finger == 3:
        return 0.0
    elif finger == 1:
        return F1_OFFSET_FM0 + t * (F1_OFFSET_FM120 - F1_OFFSET_FM0)
    elif finger == 5:
        return F5_OFFSET_FM0 + t * (F5_OFFSET_FM120 - F5_OFFSET_FM0)
    elif finger == 2:
        # Always +1 semitone width above finger 1 (toward right / lower degree)
        return finger_offset(1, fm) - BLACK_SPACING
    elif finger == 4:
        # Always -1 semitone width below finger 5 (toward left / higher degree)
        return finger_offset(5, fm) + BLACK_SPACING

    raise ValueError(f"Unknown finger {finger}")


def sp_for_finger_on_key(finger: int, key: str, fm: float) -> float:
    """
    Return the SP (degree of finger 3) needed so that <finger> at <fm>
    lands exactly on <key>.
    """
    key_deg = KEY_DEGREES[key]
    offset = finger_offset(finger, fm)
    # key_deg = SP + offset  →  SP = key_deg - offset
    return key_deg - offset


def key_at_finger(finger: int, sp: float, fm: float) -> Optional[str]:
    """
    Return the nearest valid key (white for 1/3/5, black for 2/4) that
    finger lands on given SP and FM. Returns None if no valid key is
    within ½ semitone tolerance OR the position is out of playable range.
    """
    deg = sp + finger_offset(finger, fm)
    if not in_range(deg):
        return None

    target_colour = "black" if finger in (2, 4) else "white"

    best_key = None
    best_dist = math.inf
    for k, d in KEY_DEGREES.items():
        if ((is_black(k) and target_colour == "black") or
                (is_white(k) and target_colour == "white")):
            dist = abs(d - deg)
            if dist < best_dist:
                best_dist = dist
                best_key = k

    # Tolerance: half a semitone width (15°)
    tolerance = BLACK_SPACING / 2.0
    return best_key if best_dist <= tolerance else None


# ---------------------------------------------------------------------------
# 3.  VALID ASSIGNMENTS PER NOTE
# ---------------------------------------------------------------------------
#
# For a target note, enumerate all (finger, SP, FM) triples that can play it.
# FM is swept in steps; for each FM we compute the exact SP needed, then
# verify all constraints hold.

FM_STEPS = 5  # granularity for FM search (0, 5, 10 … 120 → 25 values)


@dataclass(frozen=True)
class Assignment:
    note: str
    finger: int
    sp: float
    fm: int
    comment: str = ""


def valid_assignments(note: str) -> list[Assignment]:
    """
    Return every (finger, SP, FM) combination that can play <note>,
    subject to all hard constraints.
    """
    black = is_black(note)
    candidate_fingers = [2, 4] if black else [1, 3, 5]

    results: list[Assignment] = []

    for finger in candidate_fingers:
        for fm_raw in range(0, 121, FM_STEPS):
            sp = sp_for_finger_on_key(finger, note, fm_raw)

            landed = key_at_finger(finger, sp, fm_raw)
            if landed != note:
                continue

            if not (0 <= fm_raw <= 120):
                continue

            ok = True
            for f in (1, 2, 3, 4, 5):
                d = sp + finger_offset(f, fm_raw)
                if not in_range(d):
                    ok = False
                    break

            if ok:
                results.append(
                    Assignment(
                        note=note,
                        finger=finger,
                        sp=round(sp, 2),
                        fm=fm_raw,
                    )
                )

    return results


# ---------------------------------------------------------------------------
# 4.  DYNAMIC PROGRAMMING OPTIMISER
# ---------------------------------------------------------------------------

COST_A = 10.0            # startup cost for motor A if it moves
COST_A_PER_DIST = 5.0   # distance cost for motor A
COST_B = 1.0            # linear cost weight for motor B


def transition_cost(a: Assignment, b: Assignment) -> float:
    """Cost to move from state a to state b."""
    delta_sp = abs(b.sp - a.sp)
    delta_fm = abs(b.fm - a.fm)

    motor_a_cost = (COST_A + COST_A_PER_DIST * delta_sp) if delta_sp > 1e-9 else 0.0
    motor_b_cost = COST_B * delta_fm

    return motor_a_cost + motor_b_cost


@dataclass
class DPState:
    assignment: Assignment
    total_cost: float = math.inf
    prev: Optional["DPState"] = field(default=None, repr=False)


def optimise(score: list[tuple[str, float]],
             cost_a: float = COST_A,
             cost_b: float = COST_B) -> list[tuple[Assignment, str]]:
    """
    Run DP over the score.

    score  : list of (note, duration_seconds)
    Returns: list of (Assignment, comment) for each note event,
             in order, with the minimum total motor-travel cost.
    """
    global COST_A, COST_B
    COST_A = cost_a
    COST_B = cost_b

    if not score:
        return []

    notes = [n for n, _ in score]
    n_notes = len(notes)

    assignment_cache: dict[str, list[Assignment]] = {}
    for note in set(notes):
        assignments = valid_assignments(note)
        if not assignments:
            raise ValueError(f"No valid assignment found for note {note}")
        assignment_cache[note] = assignments

    prev_layer: list[DPState] = [
        DPState(assignment=a, total_cost=0.0, prev=None)
        for a in assignment_cache[notes[0]]
    ]

    for i in range(1, n_notes):
        note = notes[i]
        candidates = assignment_cache[note]
        curr_layer: list[DPState] = []

        for cand in candidates:
            best_cost = math.inf
            best_prev = None

            for ps in prev_layer:
                c = ps.total_cost + transition_cost(ps.assignment, cand)
                if c < best_cost:
                    best_cost = c
                    best_prev = ps

            curr_layer.append(
                DPState(
                    assignment=cand,
                    total_cost=best_cost,
                    prev=best_prev,
                )
            )

        prev_layer = curr_layer

    final_state = min(prev_layer, key=lambda s: s.total_cost)

    path: list[DPState] = []
    s = final_state
    while s is not None:
        path.append(s)
        s = s.prev
    path.reverse()

    result: list[tuple[Assignment, str]] = []
    for idx, state in enumerate(path):
        a = state.assignment
        note = notes[idx]
        comment_parts = []

        if idx > 0:
            prev_a = path[idx - 1].assignment
            if note == notes[idx - 1]:
                comment_parts.append("repeat")
                if a.finger != prev_a.finger:
                    comment_parts.append("switch finger to avoid bounce")

            if abs(a.sp - prev_a.sp) < 1e-3:
                comment_parts.append("SP unchanged")
            if abs(a.fm - prev_a.fm) < 1e-3:
                comment_parts.append("FM unchanged")

        result.append((a, "; ".join(comment_parts) if comment_parts else "—"))

    return result


# ---------------------------------------------------------------------------
# 5.  COMMAND SEQUENCE GENERATOR
# ---------------------------------------------------------------------------

def generate_commands(
    score: list[tuple[str, float]],
    optimised: list[tuple[Assignment, str]]
) -> list[str]:
    """
    Translate the optimised assignment table into the raw UART command sequence.
    Returns a list of human-readable command strings with timing annotations.
    """
    commands: list[str] = []
    prev_sp: Optional[float] = None
    prev_fm: Optional[int] = None

    for idx, ((asgn, _comment), (note, duration)) in enumerate(zip(optimised, score)):
        commands.append(
            f"# Note {idx + 1}: {note}  dur={duration:.3f}s  "
            f"finger={asgn.finger}  SP={asgn.sp}  FM={asgn.fm}"
        )

        # Step 1: release all fingers
        commands.append("SL = 0!")

        # Step 2: move big motor if needed
        if prev_sp is None or abs(asgn.sp - prev_sp) > 0.5:
            commands.append(f"SP = {asgn.sp}!")

        # Step 3: move small motor if needed
        if prev_fm is None or asgn.fm != prev_fm:
            commands.append(f"FM = {asgn.fm}!")

        # Step 4: wait for motors to settle
        if ((prev_sp is not None and abs(asgn.sp - prev_sp) > 0.5) or
                (prev_fm is not None and asgn.fm != prev_fm) or
                prev_sp is None):
            commands.append("WAIT 200ms")

        # Step 5: press finger
        commands.append(f"SL = {asgn.finger}!")

        # Step 6: hold for note duration
        commands.append(f"WAIT {int(duration * 1000)}ms  # hold note")

        # Step 7: release for the final note
        if idx == len(optimised) - 1:
            commands.append("SL = 0!")

        prev_sp = asgn.sp
        prev_fm = asgn.fm

    return commands


# ---------------------------------------------------------------------------
# 6.  OUTPUT TABLE PRINTER
# ---------------------------------------------------------------------------

def print_table(score: list[tuple[str, float]],
                optimised: list[tuple[Assignment, str]]) -> None:
    hdr = f"{'#':>4}  {'Note':<6}  {'Dur(s)':>7}  {'Finger':>6}  {'SP(°)':>8}  {'FM':>4}  Comment"
    print(hdr)
    print("-" * len(hdr))

    for idx, ((asgn, comment), (note, duration)) in enumerate(zip(optimised, score)):
        print(
            f"{idx + 1:>4}  {note:<6}  {duration:>7.3f}  "
            f"{asgn.finger:>6}  {asgn.sp:>8.2f}  {asgn.fm:>4}  {comment}"
        )


# ---------------------------------------------------------------------------
# 7.  SCORE PARSER
# ---------------------------------------------------------------------------

def parse_score(text: str) -> list[tuple[str, float]]:
    """Parse whitespace-separated 'NOTE DURATION' pairs."""
    tokens = text.split()
    if len(tokens) % 2 != 0:
        raise ValueError("Score must contain interleaved NOTE DURATION pairs.")

    pairs = []
    for i in range(0, len(tokens), 2):
        note = tokens[i]
        duration = float(tokens[i + 1])
        if note not in KEY_DEGREES:
            raise ValueError(f"Unknown note: {note}")
        pairs.append((note, duration))

    return pairs


# ---------------------------------------------------------------------------
# 8.  MAIN
# ---------------------------------------------------------------------------

TWINKLE = """
C4 0.602    C4 0.602    G4 0.602    G4 0.602
A4 0.602    A4 0.602    G4 1.201
F4 0.602    F4 0.602    E4 0.602    E4 0.602
D4 0.602    D4 0.602    C4 1.201
G4 0.602    G4 0.602    F4 0.602    F4 0.602
E4 0.602    E4 0.602    D4 1.201
G4 0.602    G4 0.602    F4 0.602    F4 0.602
E4 0.602    E4 0.602    D4 1.201
C4 0.602    C4 0.602    G4 0.602    G4 0.602
A4 0.602    A4 0.602    G4 1.201
F4 0.602    F4 0.602    E4 0.602    E4 0.602
D4 0.602    D4 0.602    C4 1.201
"""

if __name__ == "__main__":
    score = parse_score(TWINKLE)
    optimised = optimise(score, cost_a=3.0, cost_b=1.0)

    print("=" * 72)
    print("OPTIMISED COMMAND TABLE")
    print("=" * 72)
    print_table(score, optimised)

    total = sum(
        (
            (COST_A + COST_A_PER_DIST * abs(optimised[i][0].sp - optimised[i - 1][0].sp))
            if abs(optimised[i][0].sp - optimised[i - 1][0].sp) > 1e-9
            else 0.0
        )
        + COST_B * abs(optimised[i][0].fm - optimised[i - 1][0].fm)
        for i in range(1, len(optimised))
    )
    print(f"\nTotal motor travel cost: {total:.2f}  (a={COST_A}, b={COST_B})")

    print("\n" + "=" * 72)
    print("UART COMMAND SEQUENCE")
    print("=" * 72)
    for cmd in generate_commands(score, optimised):
        print(cmd)