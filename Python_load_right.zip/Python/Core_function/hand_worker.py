# Core_function/hand_worker.py
import queue
import threading
import time
from typing import Optional, Any

from Core_function.note import note_to_angle


CENTER_TOL_DEG = 5
CENTER_WAIT_S = 5

SPREAD_SETTLE_S = 0.08
SPREAD_WAIT_S = 2
SPREAD_TOL_DEG = 12.0

SPREAD_LEVEL_TO_ANGLE = {
    0: 0.0,
    1: 40.0,
    2: 80.0,
    3: 120.0,
    4: 160.0,
}

HOME_WAIT_S = 4.5

# optional stability requirement for "ready"
READY_STABLE_COUNT = 3

FINGER_TO_SOLENOID = {
    "Lw": 1,
    "Lb": 2,
    "M": 3,
    "Rb": 4,
    "Rw": 5,
}

SOLENOID_ORDER = ("Lw", "Lb", "M", "Rb", "Rw")


class HandWorker(threading.Thread):
    """
    Command-driven single-hand worker.

    Expected cmd_q messages from DualHandConductor:

    1) idle_prepare
    {
        "type": "idle_prepare",
        "hand": "left" / "right",
        "event_index": 3,
        "start_time": 2.40,
        "end_time": 2.90,
        "event": <planned_event_dict>,
    }

    2) prepare
    {
        "type": "prepare",
        "hand": "left" / "right",
        "attack_id": 7,
        "event_index": 5,
        "attack_time": 3.50,
        "event": <planned_event_dict>,
    }

    3) press
    {
        "type": "press",
        "hand": "left" / "right",
        "attack_id": 7,
        "event_index": 5,
        "event": <planned_event_dict>,
    }

    4) release
    {
        "type": "release",
        "hand": "left" / "right",
        "attack_id": 7,
        "event_index": 5,
        "event": <planned_event_dict>,
    }

    5) stop
    {
        "type": "stop",
        "hand": "left" / "right",
    }

    Status messages sent to status_q:

    ready:
    {
        "type": "ready",
        "hand": self.hand,
        "attack_id": 7,
    }

    error:
    {
        "type": "error",
        "hand": self.hand,
        "attack_id": 7,   # optional
        "message": "...",
    }
    """

    def __init__(
        self,
        hand: str,
        reader,
        cmd_q: queue.Queue,
        status_q: queue.Queue,
        out_q: Optional[queue.Queue] = None,
        stop_evt: Optional[threading.Event] = None,
        pause_evt: Optional[threading.Event] = None,
        get_actual_center_fn=None,
        get_actual_spread_fn=None,
        auto_home_on_start: bool = False,
    ):
        super().__init__(daemon=True)

        self.hand = str(hand).strip().lower()
        self.reader = reader
        self.cmd_q = cmd_q
        self.status_q = status_q
        self.out_q = out_q

        self.stop_evt = stop_evt if stop_evt is not None else threading.Event()
        self.pause_evt = pause_evt if pause_evt is not None else threading.Event()

        self.get_actual_center_fn = (
            get_actual_center_fn if get_actual_center_fn is not None else (lambda: None)
        )
        self.get_actual_spread_fn = (
            get_actual_spread_fn if get_actual_spread_fn is not None else (lambda: None)
        )

        self.auto_home_on_start = bool(auto_home_on_start)

        # confirmed ready state
        self._last_center_target_angle = None
        self._last_spread = None

        # pending spread motion
        self._pending_spread_target = None
        self._pending_spread_sent_at = None

        # pause / active press state
        self._pause_notified = False
        self._pause_release_sent = False
        self._has_active_press = False
        self._active_solenoid_digits = ""

    # ========================================================
    # basic emit/log
    # ========================================================
    def _emit(self, kind: str, payload: Any):
        if self.out_q is not None:
            self.out_q.put((kind, payload))

    def _log(self, text: str):
        self._emit("status", f"[HandWorker-{self.hand}] {text}")

    def _status_ready(self, attack_id: int):
        self.status_q.put({
            "type": "ready",
            "hand": self.hand,
            "attack_id": int(attack_id),
        })

    def _status_error(self, message: str, attack_id: Optional[int] = None):
        payload = {
            "type": "error",
            "hand": self.hand,
            "message": str(message),
        }
        if attack_id is not None:
            payload["attack_id"] = int(attack_id)
        self.status_q.put(payload)
        self._emit("error", f"[HandWorker-{self.hand}] {message}")

    # ========================================================
    # normalization helpers
    # ========================================================
    def _safe_duration(self, duration) -> float:
        try:
            d = float(duration)
        except Exception:
            d = 0.0
        return max(0.01, d)

    def _safe_int(self, x, default=0) -> int:
        try:
            return int(x)
        except Exception:
            return int(default)

    def _norm_note(self, x) -> str:
        s = str("" if x is None else x).strip().upper()
        return s

    def _norm_notes(self, xs):
        if xs is None:
            return []
        if isinstance(xs, str):
            n = self._norm_note(xs)
            return [] if n in ("", "REST") else [n]

        out = []
        seen = set()
        for x in xs:
            n = self._norm_note(x)
            if n in ("", "REST"):
                continue
            if n not in seen:
                seen.add(n)
                out.append(n)
        return out

    def _norm_finger(self, x) -> str:
        return str("REST" if x is None else x).strip()

    def _norm_fingers(self, xs):
        if xs is None:
            return []
        if isinstance(xs, str):
            f = self._norm_finger(xs)
            return [] if f == "REST" else [f]

        out = []
        seen = set()
        for x in xs:
            f = self._norm_finger(x)
            if f == "REST":
                continue
            if f not in seen:
                seen.add(f)
                out.append(f)
        return out

    def _norm_note_finger_map(self, mp):
        if not isinstance(mp, dict):
            return {}
        out = {}
        for k, v in mp.items():
            n = self._norm_note(k)
            f = self._norm_finger(v)
            if n in ("", "REST") or f == "REST":
                continue
            out[n] = f
        return out

    # ========================================================
    # event extraction
    # ========================================================
    def _event_center_angle(self, ev: dict):
        x = ev.get("center_angle_override", None)
        if x is not None:
            try:
                return float(x)
            except Exception:
                pass

        center_note = self._norm_note(ev.get("center_note", ""))
        if not center_note:
            return None

        try:
            return float(note_to_angle(center_note, self.hand))    
        except Exception:
            return None

    def _event_spread_level(self, ev: dict) -> int:
        return self._safe_int(ev.get("spread", 0), 0)

    def _event_spread_angle(self, ev: dict):
        x = ev.get("spread_angle_override", None)
        if x is not None:
            try:
                return float(x)
            except Exception:
                pass

        spread = self._event_spread_level(ev)
        return SPREAD_LEVEL_TO_ANGLE.get(spread, 0.0)

    def _event_finger_ids(self, ev: dict):
        finger_ids = self._norm_fingers(ev.get("finger_ids", []))
        if finger_ids:
            return finger_ids

        mp = self._norm_note_finger_map(ev.get("note_finger_map", {}))
        if mp:
            seen = set()
            out = []
            for fid in SOLENOID_ORDER:
                if fid in mp.values() and fid not in seen:
                    out.append(fid)
                    seen.add(fid)
            if out:
                return out

        notes = self._norm_notes(ev.get("notes", []))
        if len(notes) == 1:
            return ["M"]

        return []

    # ========================================================
    # serial helpers
    # ========================================================
    def _write_cmd(self, cmd: str):
        self.reader.write(cmd)

    def _send_center(self, center_note: str) -> float:
        angle = note_to_angle(center_note, self.hand)
        self._write_cmd(f"SP={angle:.2f}!")
        return angle

    def _send_center_angle(self, angle: float) -> float:
        angle = float(angle)
        self._write_cmd(f"SP={angle:.2f}!")
        return angle

    def _send_spread_cmd(self, spread: int):
        self._write_cmd(f"SF={int(spread)}!")

    def _finger_ids_to_solenoid_digits(self, finger_ids):
        chosen = set(self._norm_fingers(finger_ids))
        digits = []
        for fid in SOLENOID_ORDER:
            if fid in chosen:
                digits.append(str(FINGER_TO_SOLENOID[fid]))
        return "".join(digits)

    def _press_fingers(self, finger_ids):
        digits = self._finger_ids_to_solenoid_digits(finger_ids)
        if not digits:
            raise ValueError("No valid finger_ids to press.")
        self._write_cmd(f"SL={digits}!")
        self._has_active_press = True
        self._active_solenoid_digits = digits
        return digits

    def _release_all(self):
        self._write_cmd("SL=0!")
        self._has_active_press = False
        self._active_solenoid_digits = ""

    def _start_spread_motion(self, spread: int):
        spread = int(spread)
        self._send_spread_cmd(spread)
        self._pending_spread_target = spread
        self._pending_spread_sent_at = time.perf_counter()

    def _spread_target_angle(self, spread: int) -> float:
        spread = int(spread)
        if spread not in SPREAD_LEVEL_TO_ANGLE:
            raise ValueError(f"Unsupported spread level: {spread}")
        return SPREAD_LEVEL_TO_ANGLE[spread]

    def _spread_remaining_wait_s(self) -> float:
        if self._pending_spread_target is None or self._pending_spread_sent_at is None:
            return 0.0

        elapsed = time.perf_counter() - self._pending_spread_sent_at
        remain = SPREAD_SETTLE_S - elapsed
        return max(0.0, remain)

    def _finalize_spread_ready(self, spread=None):
        if spread is not None:
            self._last_spread = int(spread)
        elif self._pending_spread_target is not None:
            self._last_spread = self._pending_spread_target

        self._pending_spread_target = None
        self._pending_spread_sent_at = None

    # ========================================================
    # pause / stop helpers
    # ========================================================
    def _handle_pause(self) -> bool:
        if not self.pause_evt.is_set():
            self._pause_notified = False
            self._pause_release_sent = False
            return True

        if not self._pause_notified:
            self._emit("hw_paused", {"hand": self.hand})
            self._pause_notified = True

        if self._has_active_press and not self._pause_release_sent:
            try:
                self._release_all()
            except Exception:
                pass
            self._pause_release_sent = True

        while self.pause_evt.is_set() and not self.stop_evt.is_set():
            time.sleep(0.02)

        if self.stop_evt.is_set():
            return False

        self._emit("hw_resumed", {"hand": self.hand})
        self._pause_notified = False
        self._pause_release_sent = False
        return True

    def _sleep_interruptible(self, seconds: float) -> bool:
        try:
            seconds = float(seconds)
        except Exception:
            seconds = 0.0

        seconds = max(0.0, seconds)
        t0 = time.perf_counter()

        while not self.stop_evt.is_set():
            if not self._handle_pause():
                return False

            if time.perf_counter() - t0 >= seconds:
                return True

            time.sleep(0.005)

        return False

    # ========================================================
    # ready checks
    # ========================================================
    def _wait_until_center(self, target_angle: float, tol_deg: float, timeout_s: float):
        timeout_s = max(0.0, float(timeout_s))
        active_wait = 0.0
        t0 = time.perf_counter()
        last_actual = None
        stable_hits = 0

        while not self.stop_evt.is_set():
            if not self._handle_pause():
                return False, last_actual

            now = time.perf_counter()
            dt = now - t0
            t0 = now
            active_wait += dt

            try:
                actual = self.get_actual_center_fn()
            except Exception:
                actual = None

            if actual is not None:
                last_actual = actual
                if abs(actual - target_angle) <= tol_deg:
                    stable_hits += 1
                    if stable_hits >= READY_STABLE_COUNT:
                        return True, actual
                else:
                    stable_hits = 0

            if active_wait >= timeout_s:
                return False, last_actual

            time.sleep(0.005)

        return False, last_actual

    def _spread_ready_now(self, target_spread: int):
        target_spread = int(target_spread)

        if self._pending_spread_target is None and self._last_spread == target_spread:
            try:
                actual = self.get_actual_spread_fn()
            except Exception:
                actual = None
            return True, actual

        try:
            actual = self.get_actual_spread_fn()
        except Exception:
            actual = None

        if actual is not None:
            target_angle = self._spread_target_angle(target_spread)
            if abs(actual - target_angle) <= SPREAD_TOL_DEG:
                return True, actual
            return False, actual

        if self._pending_spread_target == target_spread:
            remain = self._spread_remaining_wait_s()
            if remain <= 0.0:
                return True, None
            return False, None

        if self._last_spread == target_spread:
            return True, None

        return False, None

    def _wait_until_spread_ready(self, target_spread: int, timeout_s: float):
        target_spread = int(target_spread)

        try:
            probe = self.get_actual_spread_fn()
        except Exception:
            probe = None

        # feedback mode
        if probe is not None:
            timeout_s = max(0.0, float(timeout_s))
            active_wait = 0.0
            t0 = time.perf_counter()
            last_actual = probe
            stable_hits = 0

            while not self.stop_evt.is_set():
                if not self._handle_pause():
                    return False, last_actual

                now = time.perf_counter()
                dt = now - t0
                t0 = now
                active_wait += dt

                try:
                    actual = self.get_actual_spread_fn()
                except Exception:
                    actual = None

                if actual is not None:
                    last_actual = actual
                    if abs(actual - self._spread_target_angle(target_spread)) <= SPREAD_TOL_DEG:
                        stable_hits += 1
                        if stable_hits >= READY_STABLE_COUNT:
                            self._finalize_spread_ready(target_spread)
                            return True, actual
                    else:
                        stable_hits = 0

                if active_wait >= timeout_s:
                    return False, last_actual

                time.sleep(0.005)

            return False, last_actual

        # open-loop fallback
        if self._pending_spread_target is None:
            return True, None

        remain = self._spread_remaining_wait_s()
        if remain > 0.0:
            ok = self._sleep_interruptible(remain)
            if not ok:
                return False, None

        self._finalize_spread_ready(target_spread)
        return True, None

    def _ensure_spread_ready(self, target_spread: int):
        target_spread = int(target_spread)

        if self._pending_spread_target is None and self._last_spread == target_spread:
            try:
                actual = self.get_actual_spread_fn()
            except Exception:
                actual = None
            return True, actual

        ready, actual = self._spread_ready_now(target_spread)
        if ready:
            self._finalize_spread_ready(target_spread)
            return True, actual

        if self._pending_spread_target != target_spread:
            try:
                self._start_spread_motion(target_spread)
            except Exception:
                return False, None

        ok, actual = self._wait_until_spread_ready(
            target_spread=target_spread,
            timeout_s=SPREAD_WAIT_S,
        )
        if ok:
            return True, actual

        # one retry
        try:
            self._start_spread_motion(target_spread)
        except Exception:
            return False, actual

        ok, actual = self._wait_until_spread_ready(
            target_spread=target_spread,
            timeout_s=SPREAD_WAIT_S,
        )
        return ok, actual

    # ========================================================
    # movement / prepare
    # ========================================================
    def _prepare_event(self, ev: dict, attack_id: Optional[int], idle_only: bool = False):
        notes = self._norm_notes(ev.get("notes", []))
        center_note = self._norm_note(ev.get("center_note", ""))
        spread = self._safe_int(ev.get("spread", 0), 0)

        center_angle_override = ev.get("center_angle_override", None)
        try:
            center_angle_override = None if center_angle_override is None else float(center_angle_override)
        except Exception:
            center_angle_override = None

        target_center_angle = None
        if center_angle_override is not None:
            target_center_angle = float(center_angle_override)
        elif center_note:
            try:
                target_center_angle = float(note_to_angle(center_note, self.hand))
            except Exception:
                target_center_angle = None

        need_center_move = False
        if target_center_angle is not None:
            if self._last_center_target_angle is None:
                need_center_move = True
            elif abs(target_center_angle - self._last_center_target_angle) > 1e-6:
                need_center_move = True

        if need_center_move:
            try:
                if center_angle_override is not None:
                    target_center_angle = self._send_center_angle(target_center_angle)
                else:
                    target_center_angle = self._send_center(center_note)
            except Exception as e:
                self._status_error(f"Failed to send center move: {e}", attack_id=attack_id)
                return False

            ok, actual = self._wait_until_center(
                target_angle=target_center_angle,
                tol_deg=CENTER_TOL_DEG,
                timeout_s=CENTER_WAIT_S,
            )
            self._emit("hw_center_result", {
                "hand": self.hand,
                "attack_id": attack_id,
                "notes": notes,
                "target_angle": target_center_angle,
                "actual_angle": actual,
                "reached": ok,
                "idle_only": idle_only,
            })
            if not ok:
                self._status_error("Center timeout", attack_id=attack_id)
                return False

            self._last_center_target_angle = target_center_angle

        spread_ok, actual_spread = self._ensure_spread_ready(spread)
        self._emit("hw_spread_result", {
            "hand": self.hand,
            "attack_id": attack_id,
            "target_spread": spread,
            "actual_spread_angle": actual_spread,
            "reached": spread_ok,
            "idle_only": idle_only,
        })
        if not spread_ok:
            self._status_error(f"Spread not ready on level {spread}", attack_id=attack_id)
            return False

        return True

    # ========================================================
    # command handlers
    # ========================================================
    def _handle_idle_prepare(self, cmd: dict):
        ev = dict(cmd.get("event", {}) or {})
        event_index = cmd.get("event_index", None)

        ok = self._prepare_event(ev, attack_id=None, idle_only=True)
        if ok:
            self._emit("hw_idle_ready", {
                "hand": self.hand,
                "event_index": event_index,
            })

    def _handle_prepare(self, cmd: dict):
        attack_id = cmd.get("attack_id", None)
        event_index = cmd.get("event_index", None)
        ev = dict(cmd.get("event", {}) or {})

        ok = self._prepare_event(ev, attack_id=attack_id, idle_only=False)
        if ok:
            if attack_id is not None:
                self._status_ready(int(attack_id))
            self._emit("hw_ready", {
                "hand": self.hand,
                "attack_id": attack_id,
                "event_index": event_index,
            })

    def _handle_press(self, cmd: dict):
        attack_id = cmd.get("attack_id", None)
        event_index = cmd.get("event_index", None)
        ev = dict(cmd.get("event", {}) or {})

        finger_ids = self._event_finger_ids(ev)
        notes = self._norm_notes(ev.get("notes", []))

        try:
            digits = self._press_fingers(finger_ids)
        except Exception as e:
            self._status_error(f"Failed to press fingers {finger_ids}: {e}", attack_id=attack_id)
            return

        self._emit("hw_press", {
            "hand": self.hand,
            "attack_id": attack_id,
            "event_index": event_index,
            "notes": notes,
            "finger_ids": finger_ids,
            "solenoid": digits,
        })

    def _handle_release(self, cmd: dict):
        attack_id = cmd.get("attack_id", None)
        event_index = cmd.get("event_index", None)
        ev = dict(cmd.get("event", {}) or {})
        notes = self._norm_notes(ev.get("notes", []))

        try:
            self._release_all()
        except Exception as e:
            self._status_error(f"Failed to send SL=0!: {e}", attack_id=attack_id)
            return

        self._emit("hw_release", {
            "hand": self.hand,
            "attack_id": attack_id,
            "event_index": event_index,
            "notes": notes,
        })

    def _do_home(self):
        try:
            self._emit("hw_home_start", {"hand": self.hand})
            self._write_cmd("RE=1!")
        except Exception as e:
            self._status_error(f"Failed to send RE=1!: {e}", attack_id=None)
            return False

        t0 = time.perf_counter()
        while not self.stop_evt.is_set():
            if not self._handle_pause():
                return False
            if time.perf_counter() - t0 >= HOME_WAIT_S:
                break
            time.sleep(0.01)

        if self.stop_evt.is_set():
            return False

        try:
            self._start_spread_motion(0)
            ok, _ = self._wait_until_spread_ready(0, SPREAD_WAIT_S)
            if ok:
                self._finalize_spread_ready(0)
            else:
                # fallback
                time.sleep(SPREAD_SETTLE_S)
                self._finalize_spread_ready(0)
        except Exception:
            pass

        self._last_center_target_angle = None
        self._emit("hw_home_done", {"hand": self.hand})
        return True

    # ========================================================
    # main loop
    # ========================================================
    def run(self):
        self._emit("hw_started", {"hand": self.hand})

        if self.auto_home_on_start:
            ok = self._do_home()
            if not ok and self.stop_evt.is_set():
                return

        while not self.stop_evt.is_set():
            if not self._handle_pause():
                break

            try:
                cmd = self.cmd_q.get(timeout=0.02)
            except queue.Empty:
                continue

            if not isinstance(cmd, dict):
                continue

            cmd_type = str(cmd.get("type", "")).strip().lower()
            hand = str(cmd.get("hand", self.hand)).strip().lower()
            if hand and hand != self.hand:
                continue

            if cmd_type == "stop":
                break

            elif cmd_type == "idle_prepare":
                self._handle_idle_prepare(cmd)

            elif cmd_type == "prepare":
                self._handle_prepare(cmd)

            elif cmd_type == "press":
                self._handle_press(cmd)

            elif cmd_type == "release":
                self._handle_release(cmd)

            else:
                self._emit("hw_unknown_cmd", {
                    "hand": self.hand,
                    "cmd": dict(cmd),
                })

        # safe exit
        try:
            self._release_all()
        except Exception:
            pass

        self._emit("hw_stopped", {"hand": self.hand})