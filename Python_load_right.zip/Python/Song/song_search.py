import os
import re
import random
import difflib

from Core_function.note import note_to_angle
from Song.midi_loader import load_score_from_midi, note_name_to_midi_num, midi_note_to_name
from Song.ai_backend import ask_ai_for_song, generate_song_notes_from_title

SONG_LIST_DIR = os.path.join(os.path.dirname(__file__), "Song_list")

LOW_NOTE = "E3"
HIGH_NOTE = "E5"
LOW_MIDI = note_name_to_midi_num(LOW_NOTE)
HIGH_MIDI = note_name_to_midi_num(HIGH_NOTE)

MIN_DURATION = 0.12
MAX_DURATION = 1.50


def _normalize_text(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[_\-]+", " ", s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _looks_like_song_query(query: str) -> bool:
    nq = _normalize_text(query)
    if not nq:
        return False
    if len(nq) < 2:
        return False
    if len(nq.split()) > 10:
        return False
    return bool(re.search(r"[a-z0-9]", nq))


def _clamp_duration(dur: float) -> float:
    try:
        dur = float(dur)
    except (TypeError, ValueError):
        dur = 0.5
    return max(MIN_DURATION, min(MAX_DURATION, dur))


def _clamp_note_to_range(note: str) -> str:
    note = str(note).strip().upper()
    midi = note_name_to_midi_num(note)

    while midi < LOW_MIDI:
        midi += 12
    while midi > HIGH_MIDI:
        midi -= 12

    fixed = midi_note_to_name(midi)
    note_to_angle(fixed)
    return fixed


def sanitize_song(song):
    fixed = []

    for item in song:
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            continue

        notes_obj, dur = item
        dur = _clamp_duration(dur)

        # 统一成 notes 列表
        if notes_obj is None:
            notes = []
        elif isinstance(notes_obj, str):
            s = notes_obj.strip().upper()
            if s == "REST":
                notes = []
            else:
                notes = [s]
        else:
            notes = []
            for x in notes_obj:
                s = str(x).strip().upper()
                if s and s != "REST":
                    notes.append(s)

        cleaned_notes = []
        seen = set()

        for note in notes:
            try:
                note = _clamp_note_to_range(note)
                note_to_angle(note)
            except Exception:
                continue

            if note not in seen:
                cleaned_notes.append(note)
                seen.add(note)

        fixed.append((cleaned_notes, dur))

    return fixed

def _scan_local_song_files():
    items = []

    if not os.path.isdir(SONG_LIST_DIR):
        return items

    for fname in os.listdir(SONG_LIST_DIR):
        lower = fname.lower()
        if not (lower.endswith(".mid") or lower.endswith(".midi")):
            continue

        path = os.path.join(SONG_LIST_DIR, fname)
        display_title = os.path.splitext(fname)[0]
        title = _normalize_text(display_title)

        items.append({
            "title": title,
            "display_title": display_title,
            "path": path,
        })

    return items


def _find_exact_match(query: str, items):
    nq = _normalize_text(query)
    for item in items:
        if item["title"] == nq:
            return item
    return None


def _find_contains_match(query: str, items):
    nq = _normalize_text(query)
    candidates = []

    for item in items:
        t = item["title"]
        if nq and (nq in t or t in nq):
            candidates.append(item)

    if len(candidates) == 1:
        return candidates[0]
    return None


def _find_suggestions(query: str, items, max_n=5):
    nq = _normalize_text(query)
    titles = [item["title"] for item in items]

    close_titles = difflib.get_close_matches(nq, titles, n=max_n, cutoff=0.40)

    suggestions = []
    for ct in close_titles:
        for item in items:
            if item["title"] == ct and item["display_title"] not in suggestions:
                suggestions.append(item["display_title"])

    return suggestions


def _search_local(query: str) -> dict:
    if not _looks_like_song_query(query):
        return {"status": "not_found"}

    items = _scan_local_song_files()
    if not items:
        return {"status": "not_found"}

    exact = _find_exact_match(query, items)
    if exact:
        try:
            score = load_score_from_midi(exact["path"])
            song = sanitize_song(score.get("right", []))
            return {
                "status": "found",
                "title": exact["display_title"],
                "song": song,
            }
        except Exception:
            return {"status": "not_found"}

    contain = _find_contains_match(query, items)
    if contain:
        try:
            score = load_score_from_midi(contain["path"])
            song = sanitize_song(score.get("right", []))
            return {
                "status": "found",
                "title": contain["display_title"],
                "song": song,
            }
        except Exception:
            return {"status": "not_found"}

    suggestions = _find_suggestions(query, items)
    if suggestions:
        top_norm = _normalize_text(suggestions[0])
        ratio = difflib.SequenceMatcher(
            None,
            _normalize_text(query),
            top_norm
        ).ratio()

        if ratio >= 0.82:
            for item in items:
                if item["display_title"] == suggestions[0]:
                    try:
                        score = load_score_from_midi(item["path"])
                        song = sanitize_song(score.get("right", []))
                        return {
                            "status": "found",
                            "title": item["display_title"],
                            "song": song,
                        }
                    except Exception:
                        return {"status": "not_found"}

        return {
            "status": "suggest",
            "suggestions": suggestions,
        }

    return {"status": "not_found"}

def search_song_query(query: str) -> dict:
    # 1) local search first
    local_result = _search_local(query)
    if local_result["status"] in ("found", "suggest"):
        return local_result

    # 2) AI fallback
    ai_result = ask_ai_for_song(query)
    mode = str(ai_result.get("mode", "")).strip().lower()

    if mode == "suggest":
        suggestions = ai_result.get("suggestions", [])
        if suggestions:
            return {
                "status": "suggest",
                "suggestions": suggestions,
            }

    if mode == "melody":
        title = str(ai_result.get("title", "(AI Melody)")).strip() or "(AI Melody)"
        song = sanitize_song(ai_result.get("song", []))
        if song:
            return {
                "status": "found",
                "title": f"(AI) {title}",
                "song": song,
            }

    title, song = build_random_demo(query)
    return {
        "status": "found",
        "title": title,
        "song": song,
    }

def build_random_demo(seed_text: str = "random demo"):
    rng = random.Random(_normalize_text(seed_text))

    playable_notes = [
        "E3", "F3", "G3", "A3", "B3",
        "C4", "D4", "E4", "F4", "G4", "A4", "B4",
        "C5", "D5", "E5"
    ]
    duration_choices = [0.20, 0.25, 0.35, 0.40, 0.50, 0.60, 0.80]

    n = rng.randint(180, 240)   # 大约 90s ~ 120s 左右
    song = []
    current_idx = rng.randint(4, 10)

    for _ in range(n):
        if rng.random() < 0.10:
            song.append(([], rng.choice([0.20, 0.25, 0.35])))
            continue

        step = rng.choice([-2, -1, -1, 0, 1, 1, 2])
        current_idx = max(0, min(len(playable_notes) - 1, current_idx + step))

        note = playable_notes[current_idx]
        dur = rng.choice(duration_choices)
        song.append(([note], dur))

    title = f"(AI Random Demo) {seed_text}"
    return title, sanitize_song(song)

def generate_song_from_selected_title(title: str) -> dict:
    """
    User already picked one suggestion.
    Now force AI to output note+duration melody.
    """
    result = generate_song_notes_from_title(title)
    mode = str(result.get("mode", "")).strip().lower()

    if mode == "melody":
        song = sanitize_song(result.get("song", []))
        if song:
            return {
                "status": "found",
                "title": f"(AI) {title}",
                "song": song,
            }

    # fallback random
    random_title, random_song = build_random_demo(title)
    return {
        "status": "found",
        "title": random_title,
        "song": random_song,
    }