from __future__ import annotations

import argparse
import os
import sys


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from Song.midi_loader import load_score_from_midi  # noqa: E402
from Core_function.hand_planner import (  # noqa: E402
    HandPlanner,
    PlannerConfig,
    sanitize_score_for_robot,
    plan_robot_score,
)


DEFAULT_MIDI_CANDIDATES = [
    r"E:\ELEC 391\code\test1\test1\Python\Song\Song_list\twinkle-twinkle-little-star.mid",
    os.path.join(SCRIPT_DIR, "Song", "Song_list", "twinkle-twinkle-little-star.mid"),
    os.path.join(SCRIPT_DIR, "twinkle-twinkle-little-star.mid"),
]


def resolve_midi_path(user_path: str | None) -> str:
    if user_path:
        if os.path.isfile(user_path):
            return user_path
        raise FileNotFoundError(f"MIDI file not found: {user_path}")

    for path in DEFAULT_MIDI_CANDIDATES:
        if os.path.isfile(path):
            return path

    raise FileNotFoundError(
        "Could not find twinkle-twinkle-little-star.mid automatically.\n"
        "Please pass it explicitly, for example:\n"
        'python demo_twinkle_midi_to_hand.py --midi "E:/.../twinkle-twinkle-little-star.mid"'
    )


def build_right_planner() -> HandPlanner:
    cfg = PlannerConfig(
        note_min="C4",
        note_max="F6",
        start_center_note="C5",
        start_spread=0,
        center_note_min="F4",
        center_note_max="D6",
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)

def build_left_planner() -> HandPlanner:
    cfg = PlannerConfig(
        note_min="C2",
        note_max="B3",   # C4 往上给右手，避免重叠
        start_center_note="C3",
        start_spread=0,
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)


def print_score(score_part, title: str):
    print(f"\n{title}")
    print("-" * len(title))
    for i, (notes, dur) in enumerate(score_part):
        print(f"[{i:02d}] notes={notes} duration={dur:.3f}s")


def print_planned(plan_part, title: str):
    print(f"\n{title}")
    print("-" * len(title))
    for i, ev in enumerate(plan_part):
        print(
            f"[{i:02d}] "
            f"notes={ev['notes']} "
            f"dur={ev['duration']:.3f}s  "
            f"center={ev['center_note']:<3} "
            f"spread={ev['spread']}  "
            f"fingers={ev['finger_ids']}  "
            f"action={ev['action_type']}  "
            f"map={ev['note_finger_map']}"
        )


def main():
    parser = argparse.ArgumentParser(
        description="Load twinkle-twinkle-little-star.mid, split left/right, then run hand planning."
    )
    parser.add_argument(
        "--midi",
        type=str,
        default=None,
        help="Path to twinkle-twinkle-little-star.mid",
    )
    parser.add_argument(
        "--min-duration",
        type=float,
        default=0.08,
        help="Minimum kept note duration in seconds.",
    )
    parser.add_argument(
        "--split-note",
        type=str,
        default="C4",
        help='Pitch split threshold for single-track MIDI. Default: "C4"',
    )
    parser.add_argument(
        "--verbose-midi",
        action="store_true",
        help="Print MIDI track analysis.",
    )
    args = parser.parse_args()

    midi_path = resolve_midi_path(args.midi)
    print(f"Using MIDI: {midi_path}")

    # --------------------------------------------------
    # STEP 1: MIDI -> raw left/right score
    # --------------------------------------------------
    raw_score = load_score_from_midi(
        midi_path,
        min_duration=args.min_duration,
        rest_merge=True,
        split_note=args.split_note,
        verbose=args.verbose_midi,
    )

    print_score(raw_score["right"], "STEP 1A: RAW RIGHT SCORE")
    print_score(raw_score["left"], "STEP 1B: RAW LEFT SCORE")

    # --------------------------------------------------
    # STEP 2: sanitize for robot playable range
    # --------------------------------------------------
    right_planner = build_right_planner()
    left_planner = build_left_planner()

    clean_score = sanitize_score_for_robot(
        raw_score,
        right_planner=right_planner,
        left_planner=left_planner,
    )

    print_score(clean_score["right"], "STEP 2A: CLEAN RIGHT SCORE")
    print_score(clean_score["left"], "STEP 2B: CLEAN LEFT SCORE")

    # --------------------------------------------------
    # STEP 3: hand planner result
    # --------------------------------------------------
    planned = plan_robot_score(
        clean_score,
        right_planner=right_planner,
        left_planner=left_planner,
    )

    print_planned(planned["right"], "STEP 3A: RIGHT HAND PLAN")
    print_planned(planned["left"], "STEP 3B: LEFT HAND PLAN")

    print("\nDone.")


if __name__ == "__main__":
    main()