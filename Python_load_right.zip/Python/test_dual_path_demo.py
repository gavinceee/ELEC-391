from __future__ import annotations

import argparse
import os

from Core_function.hand_planner import HandPlanner, PlannerConfig
from Core_function.hand_planner_dual_path import (
    default_dual_path_config,
    load_and_plan_midi_dual_path,
    plan_robot_score_dual_path,
    pretty_print_dual_path_plan,
)

try:
    from Core_function.note import note_to_angle
except Exception:
    note_to_angle = None


def build_right_planner() -> HandPlanner:
    cfg = PlannerConfig(
        note_min="C4",
        note_max="F6",
        start_center_note="C5",
        start_spread=0,
        center_note_min="F4",
        center_note_max="D6",
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)


def build_left_planner() -> HandPlanner:
    cfg = PlannerConfig(
        note_min="C2",
        note_max="B3",
        start_center_note="C3",
        start_spread=0,
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(cfg)


def print_score(score: dict, title: str = "RAW SCORE") -> None:
    print(f"\n{title}")
    print("=" * len(title))

    for hand_name in ("right", "left"):
        print(f"\n[{hand_name.upper()}]")
        events = score.get(hand_name, [])
        for i, (notes, dur) in enumerate(events):
            print(f"[{i:02d}] notes={notes} duration={dur:.3f}s")


def build_demo_score() -> dict:
    return {
        "right": [
            (["C4", "G4"], 1.201),
            (["C4", "A4"], 1.201),
            (["F4"], 0.602),
            (["E4"], 1.201),
        ],
        "left": [
            (["C3", "E3"], 1.201),
            (["F2", "A3"], 1.201),
            (["G2", "G3"], 1.201),
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Test hand_planner_dual_path with either a demo score or a MIDI file."
    )
    parser.add_argument(
        "--midi",
        type=str,
        default=None,
        help="Optional MIDI path. If omitted, uses the built-in demo score.",
    )
    parser.add_argument(
        "--min-duration",
        type=float,
        default=0.08,
        help="Minimum kept note duration when loading MIDI.",
    )
    parser.add_argument(
        "--split-note",
        type=str,
        default="C4",
        help='Split threshold when the MIDI is single-track. Default: "C4"',
    )
    parser.add_argument(
        "--verbose-midi",
        action="store_true",
        help="Print MIDI track analysis.",
    )
    args = parser.parse_args()

    dual_cfg = default_dual_path_config()
    right_planner = build_right_planner()
    left_planner = build_left_planner()

    if args.midi:
        if not os.path.isfile(args.midi):
            raise FileNotFoundError(f"MIDI not found: {args.midi}")

        result = load_and_plan_midi_dual_path(
            path=args.midi,
            right_planner=right_planner,
            left_planner=left_planner,
            dual_cfg=dual_cfg,
            note_to_angle_fn=note_to_angle,
            min_duration=args.min_duration,
            split_note=args.split_note,
            verbose=args.verbose_midi,
        )

        raw_score = result["raw_score"]
        planned = result["planned"]

        print_score(raw_score, "RAW SCORE FROM MIDI")
        pretty_print_dual_path_plan(planned["right"], "RIGHT DUAL PATH PLAN")
        pretty_print_dual_path_plan(planned["left"], "LEFT DUAL PATH PLAN")
        return

    score = build_demo_score()
    print_score(score, "DEMO RAW SCORE")

    planned = plan_robot_score_dual_path(
        score,
        right_planner=right_planner,
        left_planner=left_planner,
        dual_cfg=dual_cfg,
        note_to_angle_fn=note_to_angle,
    )

    pretty_print_dual_path_plan(planned["right"], "RIGHT DUAL PATH PLAN")
    pretty_print_dual_path_plan(planned["left"], "LEFT DUAL PATH PLAN")


if __name__ == "__main__":
    main()
