
from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import sys
import types
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, List


# ============================================================
# Import helpers
# ============================================================

def _load_module_from_file(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module {module_name} from {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _ensure_pkg(pkg_name: str):
    if pkg_name not in sys.modules:
        pkg = types.ModuleType(pkg_name)
        pkg.__path__ = []
        sys.modules[pkg_name] = pkg
    return sys.modules[pkg_name]


def bootstrap_modules(script_dir: Path):
    """
    Support both:
    1) real project package layout (Core_function/, Song/)
    2) flat local folder layout (all .py in one folder)

    MIDI loader is optional at bootstrap time, so the demo mode can still run
    even if mido is not installed.
    """
    try:
        note_mod = importlib.import_module("Core_function.note")
        hand_planner_mod = importlib.import_module("Core_function.hand_planner")
        dhc_mod = importlib.import_module("Core_function.dual_hand_conductor")
        dual_mod = importlib.import_module("Core_function.hand_planner_dual_path")
        try:
            midi_mod = importlib.import_module("Song.midi_loader")
        except Exception:
            midi_mod = None
        return {
            "note": note_mod,
            "hand_planner": hand_planner_mod,
            "dual_hand_conductor": dhc_mod,
            "midi_loader": midi_mod,
            "hand_planner_dual_path": dual_mod,
        }
    except Exception:
        pass

    _ensure_pkg("Core_function")
    _ensure_pkg("Song")

    note_mod = _load_module_from_file("Core_function.note", script_dir / "note.py")
    setattr(sys.modules["Core_function"], "note", note_mod)

    hand_planner_mod = _load_module_from_file("Core_function.hand_planner", script_dir / "hand_planner.py")
    setattr(sys.modules["Core_function"], "hand_planner", hand_planner_mod)

    dhc_mod = _load_module_from_file("Core_function.dual_hand_conductor", script_dir / "dual_hand_conductor.py")
    setattr(sys.modules["Core_function"], "dual_hand_conductor", dhc_mod)

    dual_mod = _load_module_from_file("Core_function.hand_planner_dual_path", script_dir / "hand_planner_dual_path.py")
    setattr(sys.modules["Core_function"], "hand_planner_dual_path", dual_mod)

    try:
        midi_mod = _load_module_from_file("Song.midi_loader", script_dir / "midi_loader.py")
        setattr(sys.modules["Song"], "midi_loader", midi_mod)
    except Exception:
        midi_mod = None

    return {
        "note": note_mod,
        "hand_planner": hand_planner_mod,
        "dual_hand_conductor": dhc_mod,
        "midi_loader": midi_mod,
        "hand_planner_dual_path": dual_mod,
    }


# ============================================================
# Formatting helpers
# ============================================================

def _fmt_notes(notes: List[str]) -> str:
    return "REST" if not notes else "/".join(notes)


def _fmt_fingers(fingers: List[str]) -> str:
    return "-" if not fingers else "/".join(fingers)


def _safe_float_str(x: Any, digits: int = 3) -> str:
    if x is None:
        return "-"
    try:
        return f"{float(x):.{digits}f}"
    except Exception:
        return str(x)


def _print_section(title: str):
    print("\n" + title)
    print("=" * len(title))


def _jsonify(obj: Any):
    if is_dataclass(obj):
        return _jsonify(asdict(obj))
    if isinstance(obj, dict):
        return {str(k): _jsonify(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonify(v) for v in obj]
    if isinstance(obj, set):
        return sorted(_jsonify(v) for v in obj)
    return obj


# ============================================================
# Demo score
# ============================================================

def build_demo_score() -> Dict[str, List[Any]]:
    return {
        "right": [
            (["C4", "G4"], 1.20),
            (["C4", "A4"], 1.20),
            (["F4"], 0.60),
            (["E4"], 1.20),
            ([], 0.40),
            (["G4", "B4"], 1.20),
        ],
        "left": [
            (["C3", "E3"], 1.20),
            (["F2", "A3"], 1.20),
            (["G2", "G3"], 1.20),
            ([], 0.40),
            (["C3"], 1.20),
        ],
    }


# ============================================================
# Planner configuration
# ============================================================

def make_default_planners(hand_planner_mod):
    PlannerConfig = hand_planner_mod.PlannerConfig
    HandPlanner = hand_planner_mod.HandPlanner

    right_cfg = PlannerConfig(
        note_min="C4",
        note_max="F6",
        start_center_note="C5",
        start_spread=0,
        center_note_min="F4",
        center_note_max="D6",
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    left_cfg = PlannerConfig(
        note_min="C2",
        note_max="B3",
        start_center_note="C3",
        start_spread=0,
        enable_left_black_finger=True,
        enable_right_black_finger=True,
    )
    return HandPlanner(right_cfg), HandPlanner(left_cfg)


# ============================================================
# Printing helpers
# ============================================================

def print_raw_score(score: Dict[str, List[Any]]):
    for hand in ("right", "left"):
        _print_section(f"RAW SCORE - {hand.upper()}")
        events = score.get(hand, [])
        if not events:
            print("(empty)")
            continue
        for i, item in enumerate(events):
            notes, dur = item
            print(f"[{i:02d}] notes={_fmt_notes(list(notes)):<18} dur={float(dur):.3f}s")


def print_planned_events(title: str, plan: List[dict], note_to_angle_fn=None):
    _print_section(title)
    if not plan:
        print("(empty)")
        return

    for i, ev in enumerate(plan):
        notes = list(ev.get("notes", []))
        center_note = ev.get("center_note")
        try:
            physical_center_angle = note_to_angle_fn(center_note) if (note_to_angle_fn and center_note) else None
        except Exception:
            physical_center_angle = None

        print(
            f"[{i:02d}] "
            f"notes={_fmt_notes(notes):<18} "
            f"dur={_safe_float_str(ev.get('duration'))}s "
            f"center={str(center_note):<4} "
            f"spread={str(ev.get('spread')):<4} "
            f"fingers={_fmt_fingers(list(ev.get('finger_ids', []))):<12} "
            f"path={str(ev.get('source_path')):<1} "
            f"action={str(ev.get('action_type'))}"
        )
        print(
            f"      center_mode={ev.get('center_mode')} center_slot={ev.get('center_slot')} "
            f"spread_profile={ev.get('spread_profile')}"
        )
        print(
            f"      center_angle_override={_safe_float_str(ev.get('center_angle_override'))} "
            f"spread_angle_override={_safe_float_str(ev.get('spread_angle_override'))} "
            f"physical_center_angle={_safe_float_str(physical_center_angle)}"
        )
        print(f"      note_finger_map={ev.get('note_finger_map', {})}")


def print_hand_schedule(title: str, events: List[Any]):
    _print_section(title)
    if not events:
        print("(empty)")
        return

    for ev in events:
        print(
            f"[{ev.index:02d}] hand={ev.hand:<5} "
            f"notes={_fmt_notes(ev.notes):<18} "
            f"start={ev.start_time:.3f}s end={ev.end_time:.3f}s dur={ev.duration:.3f}s "
            f"prepare={_safe_float_str(ev.prepare_time)}s attack_id={str(ev.attack_id)}"
        )
        print(
            f"      target_center_angle={_safe_float_str(ev.target_center_angle)} "
            f"target_spread_level={ev.target_spread_level} "
            f"target_spread_angle={_safe_float_str(ev.target_spread_angle)}"
        )


def print_attack_groups(groups: List[Any]):
    _print_section("ATTACK GROUPS")
    if not groups:
        print("(empty)")
        return

    for g in groups:
        members = []
        for hand in sorted(g.members.keys()):
            ev = g.members[hand]
            members.append(
                f"{hand}:{_fmt_notes(ev.notes)} @idx={ev.index} prepare={_safe_float_str(ev.prepare_time)}"
            )
        print(
            f"attack_id={g.attack_id:<3} time={g.attack_time:.3f}s members={' | '.join(members)}"
        )


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Debug MIDI -> raw score -> dual-path plan -> conductor attack table"
    )
    parser.add_argument("midi", nargs="?", help="Path to MIDI file. If omitted, use a built-in demo score.")
    parser.add_argument("--split-note", default="C4", help="Pitch split threshold for single-track MIDI mode.")
    parser.add_argument("--min-duration", type=float, default=0.08, help="Minimum note duration kept from MIDI.")
    parser.add_argument("--json-out", default="", help="Optional path to save all debug data as JSON.")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    mods = bootstrap_modules(script_dir)

    note_mod = mods["note"]
    midi_mod = mods["midi_loader"]
    hand_planner_mod = mods["hand_planner"]
    dual_mod = mods["hand_planner_dual_path"]
    dhc_mod = mods["dual_hand_conductor"]

    right_planner, left_planner = make_default_planners(hand_planner_mod)
    dual_cfg = dual_mod.default_dual_path_config()

    if args.midi:
        midi_path = Path(args.midi).expanduser().resolve()
        if not midi_path.exists():
            raise FileNotFoundError(f"MIDI not found: {midi_path}")
        if midi_mod is None:
            raise RuntimeError(
                "MIDI loading is unavailable in this environment. "
                "Please make sure mido is installed, then run this script again."
            )

        _print_section("MIDI LOAD")
        print(f"file={midi_path}")
        score = midi_mod.load_score_from_midi(
            str(midi_path),
            min_duration=args.min_duration,
            split_note=args.split_note,
            verbose=True,
        )
    else:
        _print_section("MIDI LOAD")
        print("No MIDI path given -> using built-in demo score")
        score = build_demo_score()

    print_raw_score(score)

    planned = dual_mod.plan_robot_score_dual_path(
        score,
        right_planner=right_planner,
        left_planner=left_planner,
        dual_cfg=dual_cfg,
        note_to_angle_fn=note_mod.note_to_angle,
    )

    print_planned_events("PLANNED RIGHT HAND", planned.get("right", []), note_mod.note_to_angle)
    print_planned_events("PLANNED LEFT HAND", planned.get("left", []), note_mod.note_to_angle)

    conductor = dhc_mod.DualHandConductor(
        planned_left=planned.get("left", []),
        planned_right=planned.get("right", []),
    )
    left_events = conductor._build_hand_schedule(conductor.planned_left, "left")
    right_events = conductor._build_hand_schedule(conductor.planned_right, "right")
    attack_groups = conductor._build_attack_groups(left_events, right_events)

    print_hand_schedule("LEFT HAND SCHEDULE", left_events)
    print_hand_schedule("RIGHT HAND SCHEDULE", right_events)
    print_attack_groups(attack_groups)

    if args.json_out:
        payload = {
            "raw_score": _jsonify(score),
            "planned": _jsonify(planned),
            "left_schedule": _jsonify(left_events),
            "right_schedule": _jsonify(right_events),
            "attack_groups": _jsonify(attack_groups),
        }
        out_path = Path(args.json_out).expanduser().resolve()
        out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nJSON saved to: {out_path}")


if __name__ == "__main__":
    main()
