# Core_function/note.py

LEFT_KEY_DEGREES = {
    "C2": 255.0,
    "D2": 351.1,
    "E2": 447.6,
    "F2": 547.6,
    "G2": 643.9,
    "A2": 743.9,
    "B2": 842.2,

    "C3": 940,
    "D3": 1034.8,
    "E3": 1124.1,
    # "F3": 1227.4,
    # "G3": 1323.7,
    # "A3": 1420.0,
    # "B3": 1516.3,
}

RIGHT_KEY_DEGREES = {
    "F4": 1140,
    "F#4": 1093,
    "G4": 1045,
    "G#4": 998,
    "A4": 950,
    "A#4": 903,
    "B4": 855,

    "C5": 760,
    "C#5": 713,
    "D5": 665,
    "D#5": 618,
    "E5": 570,
    "F5": 475,
    "F#5": 428,
    "G5": 380,
    "G#5": 333,
    "A5": 285,

    "A#5": 238,
    "B5": 190,
    "C6": 95,
    "C#6": 48,
    "D6": 0,
}

_FLAT_MAP = {
    "DB": "C#", "EB": "D#", "GB": "F#", "AB": "G#", "BB": "A#",

    "DB2": "C#2", "EB2": "D#2", "GB2": "F#2", "AB2": "G#2", "BB2": "A#2",
    "DB3": "C#3", "EB3": "D#3", "GB3": "F#3", "AB3": "G#3", "BB3": "A#3",
    "DB4": "C#4", "EB4": "D#4", "GB4": "F#4", "AB4": "G#4", "BB4": "A#4",
    "DB5": "C#5", "EB5": "D#5", "GB5": "F#5", "AB5": "G#5", "BB5": "A#5",
    "DB6": "C#6", "EB6": "D#6", "GB6": "F#6", "AB6": "G#6", "BB6": "A#6",
}

def _normalise_note(note_name: str) -> str:
    n = str(note_name).strip().upper()
    return _FLAT_MAP.get(n, n)

def note_to_angle_left(note_name: str) -> float:
    n = _normalise_note(note_name)
    if n not in LEFT_KEY_DEGREES:
        raise ValueError(f"{note_name!r} not in left-hand range")
    return float(LEFT_KEY_DEGREES[n])

def note_to_angle_right(note_name: str) -> float:
    n = _normalise_note(note_name)
    if n not in RIGHT_KEY_DEGREES:
        raise ValueError(f"{note_name!r} not in right-hand range")
    return float(RIGHT_KEY_DEGREES[n])

def note_to_angle(note_name: str, hand: str = "right") -> float:
    hand = str(hand).strip().lower()
    if hand == "left":
        return note_to_angle_left(note_name)
    return note_to_angle_right(note_name)

def angle_to_note_left(degrees: float) -> str:
    if not LEFT_KEY_DEGREES:
        raise ValueError("LEFT_KEY_DEGREES is empty")
    closest = min(LEFT_KEY_DEGREES.items(), key=lambda kv: abs(float(kv[1]) - float(degrees)))
    return closest[0]

def angle_to_note_right(degrees: float) -> str:
    if not RIGHT_KEY_DEGREES:
        raise ValueError("RIGHT_KEY_DEGREES is empty")
    closest = min(RIGHT_KEY_DEGREES.items(), key=lambda kv: abs(float(kv[1]) - float(degrees)))
    return closest[0]

def angle_to_note(degrees: float, hand: str = "right") -> str:
    hand = str(hand).strip().lower()
    if hand == "left":
        return angle_to_note_left(degrees)
    return angle_to_note_right(degrees)