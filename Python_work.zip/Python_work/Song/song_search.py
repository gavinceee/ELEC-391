import os
import re
import random
import difflib

from Core_function.note import note_to_angle
from Song.midi_loader import load_score_from_midi, note_name_to_midi_num, midi_note_to_name
from Song.ai_backend import ask_ai_for_song, generate_song_notes_from_title

SONG_LIST_DIR = os.path.join(os.path.dirname(__file__), "Song_list")

LOW_NOTE = "C2"
HIGH_NOTE = "F6"
LOW_MIDI = note_name_to_midi_num(LOW_NOTE)
HIGH_MIDI = note_name_to_midi_num(HIGH_NOTE)

MIN_DURATION = 0.12
MAX_DURATION = 1.50


def _normalize_text(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[_\-]+", " ", s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _looks_like_song_query(query: str) -> bool:
    nq = _normalize_text(query)
    if not nq:
        return False
    if len(nq) < 2:
        return False
    if len(nq.split()) > 10:
        return False
    return bool(re.search(r"[a-z0-9]", nq))


def _clamp_duration(dur: float) -> float:
    try:
        dur = float(dur)
    except (TypeError, ValueError):
        dur = 0.5
    return max(MIN_DURATION, min(MAX_DURATION, dur))


def _clamp_note_to_range(note: str) -> str:
    note = str(note).strip().upper()
    midi = note_name_to_midi_num(note)

    while midi < LOW_MIDI:
        midi += 12
    while midi > HIGH_MIDI:
        midi -= 12

    fixed = midi_note_to_name(midi)
    note_to_angle(fixed)
    return fixed


def sanitize_song(song):
    fixed = []

    for item in song:
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            continue

        notes_obj, dur = item
        dur = _clamp_duration(dur)

        # 统一成 notes 列表
        if notes_obj is None:
            notes = []
        elif isinstance(notes_obj, str):
            s = notes_obj.strip().upper()
            if s == "REST":
                notes = []
            else:
                notes = [s]
        else:
            notes = []
            for x in notes_obj:
                s = str(x).strip().upper()
                if s and s != "REST":
                    notes.append(s)

        cleaned_notes = []
        seen = set()

        for note in notes:
            try:
                note = _clamp_note_to_range(note)
                note_to_angle(note)
            except Exception:
                continue

            if note not in seen:
                cleaned_notes.append(note)
                seen.add(note)

        fixed.append((cleaned_notes, dur))

    return fixed

def _scan_local_song_files():
    items = []

    if not os.path.isdir(SONG_LIST_DIR):
        return items

    for fname in os.listdir(SONG_LIST_DIR):
        lower = fname.lower()
        if not (lower.endswith(".mid") or lower.endswith(".midi")):
            continue

        path = os.path.join(SONG_LIST_DIR, fname)
        display_title = os.path.splitext(fname)[0]
        title = _normalize_text(display_title)

        items.append({
            "title": title,
            "display_title": display_title,
            "path": path,
        })

    return items


def _find_exact_match(query: str, items):
    nq = _normalize_text(query)
    for item in items:
        if item["title"] == nq:
            return item
    return None


def _find_contains_match(query: str, items):
    nq = _normalize_text(query)
    candidates = []

    for item in items:
        t = item["title"]
        if nq and (nq in t or t in nq):
            candidates.append(item)

    if len(candidates) == 1:
        return candidates[0]
    return None


def _find_suggestions(query: str, items, max_n=5):
    nq = _normalize_text(query)
    titles = [item["title"] for item in items]

    close_titles = difflib.get_close_matches(nq, titles, n=max_n, cutoff=0.40)

    suggestions = []
    for ct in close_titles:
        for item in items:
            if item["title"] == ct and item["display_title"] not in suggestions:
                suggestions.append(item["display_title"])

    return suggestions


def _search_local(query: str) -> dict:
    if not _looks_like_song_query(query):
        return {"status": "not_found"}

    items = _scan_local_song_files()
    if not items:
        return {"status": "not_found"}

    exact = _find_exact_match(query, items)
    if exact:
        try:
            score = load_score_from_midi(exact["path"])
            song = sanitize_song(score.get("right", []))
            return {
                "status": "found",
                "title": exact["display_title"],
                "song": song,
            }
        except Exception:
            return {"status": "not_found"}

    contain = _find_contains_match(query, items)
    if contain:
        try:
            score = load_score_from_midi(contain["path"])
            song = sanitize_song(score.get("right", []))
            return {
                "status": "found",
                "title": contain["display_title"],
                "song": song,
            }
        except Exception:
            return {"status": "not_found"}

    suggestions = _find_suggestions(query, items)
    if suggestions:
        top_norm = _normalize_text(suggestions[0])
        ratio = difflib.SequenceMatcher(
            None,
            _normalize_text(query),
            top_norm
        ).ratio()

        if ratio >= 0.82:
            for item in items:
                if item["display_title"] == suggestions[0]:
                    try:
                        score = load_score_from_midi(item["path"])
                        song = sanitize_song(score.get("right", []))
                        return {
                            "status": "found",
                            "title": item["display_title"],
                            "song": song,
                        }
                    except Exception:
                        return {"status": "not_found"}

        return {
            "status": "suggest",
            "suggestions": suggestions,
        }

    return {"status": "not_found"}

def search_song_query(query: str) -> dict:
    # 1) local search first
    local_result = _search_local(query)
    if local_result["status"] in ("found", "suggest"):
        return local_result

    # 2) AI fallback
    ai_result = ask_ai_for_song(query)
    mode = str(ai_result.get("mode", "")).strip().lower()

    if mode == "suggest":
        suggestions = ai_result.get("suggestions", [])
        if suggestions:
            return {
                "status": "suggest",
                "suggestions": suggestions,
            }

    if mode == "melody":
        title = str(ai_result.get("title", "(AI Melody)")).strip() or "(AI Melody)"
        song = sanitize_song(ai_result.get("song", []))
        if song:
            return {
                "status": "found",
                "title": f"(AI) {title}",
                "song": song,
            }

    title, song, mode = build_random_demo(query)
    return {
        "status": "found",
        "title": title,
        "song": song,
        "mode": mode,
    }

def build_random_demo(seed_text: str = "random demo"):
    rng = random.Random(_normalize_text(seed_text))

    # -------------------------
    # 1) 选一个比较稳的调性感觉
    # -------------------------
    mode = rng.choice(["major", "minor"])

    if mode == "major":
        title_prefix = "(Demo Major)"
        progressions = [
            ["C", "G", "Am", "F", "C", "G", "F", "C"],
            ["C", "Am", "F", "G", "C", "Am", "Dm", "G"],
            ["C", "F", "C", "G", "Am", "F", "G", "C"],
        ]
        chord_bank = {
            "C": {
                "strong": ["C4", "E4", "G4", "C5", "E5"],
                "weak":   ["D4", "F4", "A4", "B4", "D5"],
            },
            "G": {
                "strong": ["G3", "B3", "D4", "G4", "B4", "D5"],
                "weak":   ["A3", "C4", "E4", "F4", "A4"],
            },
            "Am": {
                "strong": ["A3", "C4", "E4", "A4", "C5", "E5"],
                "weak":   ["B3", "D4", "F4", "G4", "B4"],
            },
            "F": {
                "strong": ["F3", "A3", "C4", "F4", "A4", "C5"],
                "weak":   ["G3", "B3", "D4", "E4", "G4"],
            },
            "Dm": {
                "strong": ["D4", "F4", "A4", "D5"],
                "weak":   ["E4", "G4", "B4", "C5"],
            },
            "Em": {
                "strong": ["E4", "G4", "B4", "E5"],
                "weak":   ["F4", "A4", "C5", "D5"],
            },
        }
        final_notes = [("G4", 0.5), ("E4", 0.5), ("C4", 1.2)]

    else:
        title_prefix = "(Demo Minor)"
        progressions = [
            ["Am", "F", "C", "G", "Am", "F", "G", "Am"],
            ["Am", "G", "F", "E", "Am", "F", "Dm", "E"],
            ["Am", "C", "G", "F", "Am", "Dm", "E", "Am"],
        ]
        chord_bank = {
            "Am": {
                "strong": ["A3", "C4", "E4", "A4", "C5", "E5"],
                "weak":   ["B3", "D4", "F4", "G4", "B4"],
            },
            "F": {
                "strong": ["F3", "A3", "C4", "F4", "A4", "C5"],
                "weak":   ["G3", "B3", "D4", "E4", "G4"],
            },
            "C": {
                "strong": ["C4", "E4", "G4", "C5", "E5"],
                "weak":   ["D4", "F4", "A4", "B4", "D5"],
            },
            "G": {
                "strong": ["G3", "B3", "D4", "G4", "B4", "D5"],
                "weak":   ["A3", "C4", "E4", "F4", "A4"],
            },
            "Dm": {
                "strong": ["D4", "F4", "A4", "D5"],
                "weak":   ["E4", "G4", "B4", "C5"],
            },
            "E": {
                "strong": ["E4", "G#4", "B4", "E5"],
                "weak":   ["F4", "A4", "C5", "D5"],
            },
        }
        final_notes = [("E4", 0.4), ("C4", 0.4), ("A3", 1.3)]

    progression = rng.choice(progressions)

    # -------------------------
    # 2) 节奏型：不是纯随机时值
    # -------------------------
    rhythm_patterns = [
        [0.50, 0.50, 0.50, 0.50],
        [1.00, 0.50, 0.50],
        [0.50, 0.25, 0.25, 1.00],
        [0.75, 0.25, 0.50, 0.50],
    ]

    # -------------------------
    # 3) 小动机方向：上行 / 下行 / 拱形 / 回摆
    # -------------------------
    contour_patterns = [
        [0, 1, 2, 1],
        [0, -1, 0, 1],
        [0, 1, 0, -1],
        [0, 2, 1, 0],
        [0, -1, -2, -1],
    ]

    def note_midi(n):
        return note_name_to_midi_num(n)

    def midi_note(m):
        return midi_note_to_name(m)

    def clamp_to_demo_range(m):
        while m < LOW_MIDI:
            m += 12
        while m > HIGH_MIDI:
            m -= 12
        return m

    def weighted_pick(candidates, current_midi, prefer_strong=False):
        cand_midis = sorted({clamp_to_demo_range(note_midi(n)) for n in candidates})
        if not cand_midis:
            return current_midi

        weights = []
        for m in cand_midis:
            dist = abs(m - current_midi)

            # 距离越近越容易被选中，旋律更顺
            base = max(1.0, 8.0 - dist)

            # 强拍稍微更倾向和弦骨干音
            if prefer_strong:
                base *= 1.35

            # 偏向中高音区域，更像旋律
            if m >= note_midi("C4"):
                base *= 1.10

            weights.append(base)

        return rng.choices(cand_midis, weights=weights, k=1)[0]

    song = []

    # 初始音：从第一个和弦强音里选
    first_chord = chord_bank[progression[0]]
    current_midi = note_midi(rng.choice(first_chord["strong"]))

    # -------------------------
    # 4) 按小节生成旋律
    # -------------------------
    for bar_idx, chord_name in enumerate(progression):
        bank = chord_bank[chord_name]
        rhythm = rng.choice(rhythm_patterns)
        contour = rng.choice(contour_patterns)

        bar_notes = []
        note_count = len(rhythm)

        for i in range(note_count):
            strong_beat = (i == 0 or i == note_count - 1)

            if strong_beat:
                pool = bank["strong"]
            else:
                # 弱拍允许用经过音，但不要太散
                if rng.random() < 0.65:
                    pool = bank["strong"] + bank["weak"]
                else:
                    pool = bank["strong"]

            picked = weighted_pick(pool, current_midi, prefer_strong=strong_beat)

            # 让旋律有一点方向感，而不是只按最近音选
            shape = contour[min(i, len(contour) - 1)]
            picked += shape * rng.choice([0, 1, 2])
            picked = clamp_to_demo_range(picked)

            # 尽量保持顺滑，避免大跳太多
            if abs(picked - current_midi) > 5:
                picked = current_midi + (3 if picked > current_midi else -3)
                picked = clamp_to_demo_range(picked)

            current_midi = picked
            bar_notes.append(midi_note(current_midi))

        # 写入这一小节
        for note_name, dur in zip(bar_notes, rhythm):
            song.append((note_name, dur))

        # 每 2 小节偶尔加一个很短的停顿，形成乐句呼吸
        if bar_idx in (1, 3, 5) and rng.random() < 0.55:
            song.append(("REST", rng.choice([0.20, 0.25, 0.35])))

    # -------------------------
    # 5) 再重复一遍，但做一点变体
    # -------------------------
    base_phrase = list(song)
    variation = []

    for note, dur in base_phrase:
        if note == "REST":
            variation.append((note, dur))
            continue

        m = note_midi(note)

        # 20% 概率做邻音或二度变化
        if rng.random() < 0.20:
            m += rng.choice([-2, -1, 1, 2])
            m = clamp_to_demo_range(m)

        variation.append((midi_note(m), dur))

    song.extend(variation)

    # -------------------------
    # 6) 收束结尾
    # -------------------------
    song.append(("REST", 0.25))
    song.extend(final_notes)

    title = f"{title_prefix} {seed_text}"
    return title, sanitize_song(song), mode

def generate_song_from_selected_title(title: str) -> dict:
    """
    User already picked one suggestion.
    Now force AI to output note+duration melody.
    """
    result = generate_song_notes_from_title(title)
    mode = str(result.get("mode", "")).strip().lower()

    if mode == "melody":
        song = sanitize_song(result.get("song", []))
        if song:
            return {
                "status": "found",
                "title": f"(AI) {title}",
                "song": song,
            }

    # fallback random
    random_title, random_song = build_random_demo(title)
    return {
        "status": "found",
        "title": random_title,
        "song": random_song,
    }