import tkinter as tk

NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


def midi_to_name(note_num: int) -> str:
    pitch = NOTE_NAMES[note_num % 12]
    octave = (note_num // 12) - 1
    return f"{pitch}{octave}"


def name_to_midi(note_name: str) -> int:
    s = note_name.strip().upper()
    if len(s) < 2:
        raise ValueError(f"Bad note: {note_name}")

    if s[1] == "#":
        pitch = s[:2]
        octave = int(s[2:])
    else:
        pitch = s[:1]
        octave = int(s[1:])

    return NOTE_NAMES.index(pitch) + (octave + 1) * 12


def is_black(note_name: str) -> bool:
    return "#" in note_name


class PianoRollView(tk.Canvas):
    BG = "#04070b"
    GRID = "#122033"

    KEY_WHITE = "#f3f3f5"
    KEY_BLACK = "#0f1115"
    KEY_BORDER = "#28313a"
    KEY_ACTIVE = "#72f2df"
    KEY_ACTIVE_SOFT = "#b6fff4"
    KEY_ARM = "#6aa8ff"
    KEYBED = "#d8dde5"
    KEY_SHADOW = "#a8b2bf"
    BLACK_KEY_GLOSS = "#2a313a"

    TEXT = "#dce7f7"
    SUBTEXT = "#8ea0b8"
    WARN = "#ffb86b"

    PLAYHEAD = "#ffffff"
    PLAYHEAD_GLOW = "#96fff1"

    def __init__(self, master, start_note="A0", end_note="C8", **kwargs):
        super().__init__(
            master,
            bg=self.BG,
            highlightthickness=0,
            **kwargs
        )

        self.start_note = start_note
        self.end_note = end_note

        start_midi = name_to_midi(start_note)
        end_midi = name_to_midi(end_note)
        if end_midi < start_midi:
            raise ValueError("end_note must be >= start_note")

        self.total_keys = end_midi - start_midi + 1
        self.key_notes = [midi_to_name(start_midi + i) for i in range(self.total_keys)]

        # 预缓存，避免每次 redraw 都重复构建
        self.white_notes = [note for note in self.key_notes if not is_black(note)]
        self.white_index_map = {note: idx for idx, note in enumerate(self.white_notes)}

        self.song = []
        self.song_total_duration = 1.0

        self.play_time = 0.0
        self.current_note = None
        self.pressed_note = None
        self.arm_note = None
        self.song_name = ""
        self.status_text = "Stopped"

        self.current_move_time = None
        self.current_move_reached = None

        self.keyboard_h = 180
        self.padding_x = 20
        self.lane_top = 48
        self.note_hit_y_gap = 12
        self.seconds_visible = 6.0

        self._redraw_pending = False

        self.bind("<Configure>", self._on_configure)

    # -------------------------
    # redraw scheduling
    # -------------------------
    def _on_configure(self, _event=None):
        self._request_redraw()

    def _request_redraw(self):
        if self._redraw_pending:
            return
        self._redraw_pending = True
        self.after_idle(self._do_redraw)

    def _do_redraw(self):
        self._redraw_pending = False
        self.redraw()

    # -------------------------
    # Public API
    # -------------------------
    def set_song(self, song_name, song):
        self.song_name = song_name
        self.song = list(song)

        total = 0.0
        for item in self.song:
            try:
                total += max(0.01, float(item[1]))
            except Exception:
                total += 0.01
        self.song_total_duration = max(0.001, total)

        self.play_time = 0.0
        self.current_note = None
        self.pressed_note = None
        self.arm_note = None
        self.current_move_time = None
        self.current_move_reached = None
        self._request_redraw()

    def set_play_time(self, seconds: float):
        try:
            self.play_time = max(0.0, float(seconds))
        except Exception:
            self.play_time = 0.0
        self._request_redraw()

    def set_current_note(self, note):
        self.current_note = str(note).strip().upper() if note else None
        self._request_redraw()

    def set_pressed_note(self, note):
        self.pressed_note = str(note).strip().upper() if note else None
        self._request_redraw()

    def set_arm_note(self, note):
        self.arm_note = str(note).strip().upper() if note else None
        self._request_redraw()

    def set_status(self, status_text: str):
        self.status_text = str(status_text)
        self._request_redraw()

    def set_move_info(self, move_time=None, reached=None):
        self.current_move_time = move_time
        self.current_move_reached = reached
        self._request_redraw()

    # 保留接口，防止外部调用报错；现在直接 no-op
    def set_note_move_time(self, idx: int, move_time: float):
        return

    def set_note_actual_press(self, idx: int, elapsed: float):
        return

    def set_note_actual_release(self, idx: int, elapsed: float):
        return

    def reset_view(self):
        self.play_time = 0.0
        self.current_note = None
        self.pressed_note = None
        self.arm_note = None
        self.current_move_time = None
        self.current_move_reached = None
        self.status_text = "Stopped"
        self._request_redraw()

    # -------------------------
    # Geometry helpers
    # -------------------------
    def _white_key_w(self):
        white_count = max(1, len(self.white_notes))
        w = max(400, self.winfo_width())
        return (w - 2 * self.padding_x) / white_count

    def _dynamic_keyboard_h(self):
        h = max(500, self.winfo_height())
        return max(190, min(280, int(h * 0.36)))

    def _white_key_height(self):
        return self._dynamic_keyboard_h()

    def _black_key_height(self):
        return int(self._white_key_height() * 0.6)

    def _black_key_width(self):
        return self._white_key_w() * 0.64

    def _x_for_note(self, note_name: str):
        if note_name not in self.key_notes:
            return None

        white_w = self._white_key_w()

        if not is_black(note_name):
            idx = self.white_index_map[note_name]
            x0 = self.padding_x + idx * white_w
            return x0, x0 + white_w

        midi_num = name_to_midi(note_name)
        prev_note = midi_to_name(midi_num - 1)
        next_note = midi_to_name(midi_num + 1)
        if prev_note not in self.white_index_map or next_note not in self.white_index_map:
            return None

        prev_right = self.padding_x + (self.white_index_map[prev_note] + 1) * white_w
        next_left = self.padding_x + self.white_index_map[next_note] * white_w
        center = (prev_right + next_left) / 2
        half_w = self._black_key_width() / 2
        return center - half_w, center + half_w

    def _keyboard_top(self):
        h = max(500, self.winfo_height())
        return h - self._white_key_height()

    def _lane_bottom(self):
        return self._keyboard_top() - self.note_hit_y_gap

    # -------------------------
    # Draw
    # -------------------------
    def redraw(self):
        self.delete("all")
        w = max(400, self.winfo_width())
        h = max(500, self.winfo_height())

        self.create_rectangle(0, 0, w, h, fill=self.BG, outline="")

        self._draw_grid()
        self._draw_hit_line()
        self._draw_keyboard()
        self._draw_overlay_text()

    def _draw_grid(self):
        white_w = self._white_key_w()

        for i in range(len(self.white_notes) + 1):
            x = self.padding_x + i * white_w
            self.create_line(x, self.lane_top, x, self._lane_bottom(), fill=self.GRID, width=1)

        for note in self.key_notes:
            if not is_black(note):
                continue
            x = self._x_for_note(note)
            if x is None:
                continue
            cx = (x[0] + x[1]) / 2
            self.create_line(cx, self.lane_top, cx, self._lane_bottom(), fill="#0d1826", width=1)

    def _draw_hit_line(self):
        y = self._lane_bottom()

        self.create_line(
            self.padding_x, y - 1,
            self.winfo_width() - self.padding_x, y - 1,
            fill=self.PLAYHEAD_GLOW,
            width=5
        )

        self.create_line(
            self.padding_x, y,
            self.winfo_width() - self.padding_x, y,
            fill=self.PLAYHEAD,
            width=2
        )

    def _draw_keyboard(self):
        top = self._keyboard_top()
        bottom = top + self._white_key_height()
        left = self.padding_x
        right = self.winfo_width() - self.padding_x

        self.create_rectangle(left, top, right, bottom, fill=self.KEYBED, outline="")
        self.create_rectangle(left, bottom - 12, right, bottom, fill=self.KEY_SHADOW, outline="")

        # white keys
        for note in self.key_notes:
            if is_black(note):
                continue

            pos = self._x_for_note(note)
            if pos is None:
                continue
            x0, x1 = pos

            fill = self.KEY_WHITE
            outline = self.KEY_BORDER
            width = 1

            is_pressed = (note == self.pressed_note)
            is_current = (note == self.current_note)
            is_arm = (note == self.arm_note)

            if is_pressed:
                fill = self.KEY_ACTIVE
            elif is_current:
                fill = self.KEY_ACTIVE_SOFT

            if is_arm:
                outline = self.KEY_ARM
                width = 3

            self.create_rectangle(x0, top, x1, bottom, fill=fill, outline=outline, width=width)
            self.create_line(x0, top, x1, top, fill="#ffffff", width=2)
            self.create_line(x0, bottom - 1, x1, bottom - 1, fill="#bdc6d2", width=1)

            if is_pressed or is_current:
                self.create_rectangle(
                    x0 + 2, top + 2, x1 - 2, top + 10,
                    fill="#f6fffd",
                    outline=""
                )

            if len(note) == 2:
                self.create_text(
                    (x0 + x1) / 2,
                    bottom - 18,
                    text=note,
                    fill="#444",
                    font=("Segoe UI", 9)
                )

        # black keys
        bh = self._black_key_height()
        for note in self.key_notes:
            if not is_black(note):
                continue

            pos = self._x_for_note(note)
            if pos is None:
                continue
            x0, x1 = pos

            fill = self.KEY_BLACK
            outline = "#000000"
            width = 1

            is_pressed = (note == self.pressed_note)
            is_current = (note == self.current_note)
            is_arm = (note == self.arm_note)

            if is_pressed:
                fill = self.KEY_ACTIVE
                outline = self.KEY_ACTIVE
            elif is_current:
                fill = "#3bcaba"
                outline = "#3bcaba"

            if is_arm:
                outline = self.KEY_ARM
                width = 3

            self.create_rectangle(
                x0, top, x1, top + bh,
                fill=fill, outline=outline, width=width
            )
            self.create_rectangle(
                x0 + 2, top + 2, x1 - 2, top + 10,
                fill=self.BLACK_KEY_GLOSS if not (is_pressed or is_current) else "#cffff9",
                outline=""
            )

            if is_pressed or is_current:
                self.create_rectangle(
                    x0 + 2, top + 2, x1 - 2, top + 8,
                    fill="#cffff9",
                    outline=""
                )

    def _draw_overlay_text(self):
        w = self.winfo_width()

        left_text = self.song_name if self.song_name else "No Song Loaded"

        self.create_text(
            18, 16,
            text=left_text,
            anchor="nw",
            fill=self.TEXT,
            font=("Segoe UI", 15, "bold")
        )

        self.create_text(
            w - 18, 16,
            text=self.status_text,
            anchor="ne",
            fill=self.SUBTEXT,
            font=("Segoe UI", 11, "bold")
        )

        if self.current_move_time is not None:
            reached_txt = "OK" if self.current_move_reached else "WAIT/TIMEOUT"
            reached_color = "#89f0dd" if self.current_move_reached else self.WARN
            self.create_text(
                18, 42,
                text=f"Move: {self.current_move_time:.3f}s",
                anchor="nw",
                fill=self.SUBTEXT,
                font=("Consolas", 10, "bold")
            )
            self.create_text(
                150, 42,
                text=f"[{reached_txt}]",
                anchor="nw",
                fill=reached_color,
                font=("Consolas", 10, "bold")
            )